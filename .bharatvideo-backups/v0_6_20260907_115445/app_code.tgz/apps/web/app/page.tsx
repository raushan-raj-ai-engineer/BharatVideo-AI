import Link from 'next/link';
const API=process.env.NEXT_PUBLIC_API_BASE_URL||'http://localhost:8000';
async function data(path:string){try{const r=await fetch(`${API}${path}`,{cache:'no-store'});return r.ok?r.json():null}catch{return null}}
export default async function Home(){
  const [analytics,providers]=await Promise.all([data('/v1/analytics/summary'),data('/v1/providers')]);
  const stats=analytics||{projects:0,scenes:0,media_assets:0,credits_used:0};
  return <>
    <section className="studioHero">
      <div><span className="eyebrow">BHARATVIDEO AI • V0.5 STUDIO</span><h1>From one idea to an editable Indian-language video.</h1><p>Plan with local AI, edit every scene, generate voice/captions, render with Blender, and keep timing safe automatically.</p><div className="heroActions"><Link href="/create" className="primaryLink">✦ Create AI video</Link><Link href="/projects" className="secondaryLink">Open projects</Link></div></div>
      <div className="heroPreview"><div className="mockFrame"><span className="mockBadge">KANPURIYA COMEDY</span><div className="mockPlay">▶</div><div className="mockCaption">“का बे Guddua, ई AI का नया भौकाल है?”</div></div></div>
    </section>
    <section className="metricGrid">
      <div className="metric"><span>Projects</span><strong>{stats.projects}</strong><small>in your studio</small></div>
      <div className="metric"><span>Scenes</span><strong>{stats.scenes}</strong><small>editable units</small></div>
      <div className="metric"><span>Assets</span><strong>{stats.media_assets}</strong><small>voice / visual / video</small></div>
      <div className="metric"><span>Local credits used</span><strong>{stats.credits_used}</strong><small>paid video APIs still off</small></div>
    </section>
    <div className="twoCol">
      <section className="panel"><div className="panelTitle"><div><span className="eyebrow">PIPELINE</span><h2>Production flow</h2></div></div><div className="flowList">{['Prompt + local LLM story','Scene editor + timing QA','Voice + captions + local media','Blender preview / final composition'].map((x,i)=><div className="flowItem" key={x}><span>{i+1}</span><div><b>{x}</b><small>{i===1?'Natural speech budget auto-fit included':'Scene-level workflow; no full-video reset required'}</small></div></div>)}</div></section>
      <section className="panel"><div className="panelTitle"><div><span className="eyebrow">PROVIDERS</span><h2>Generation status</h2></div></div><div className="providerList">{providers?Object.entries(providers).map(([name,v]:any)=><div className="provider" key={name}><span className={v.ready?'liveDot':'offDot'}/><div><b>{name.replace('_',' ')}</b><small>{v.provider}{v.model?` • ${v.model}`:''}</small></div><em>{v.ready?'READY':'OPTIONAL'}</em></div>):<p className="muted">Provider status unavailable.</p>}</div></section>
    </div>
  </>
}
