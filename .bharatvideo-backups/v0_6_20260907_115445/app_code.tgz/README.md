# BharatVideo AI MVP V0.5

Local-first AI Creator Studio for prompt → story → editable scenes → voice/captions/media → Blender/FFmpeg render.

## V0.5 release goals

V0.5 is a consolidated release. Do not apply the old V0.3.1/V0.3.2/V0.4 hotfixes after it.

### Render reliability

- Renderer **V6.6 actual-WAV duration self-heal**.
- Exact `3.59s voice / 3.00s scene / 1.15x cap` regression covered by automated test.
- Complete dialogue turns are protected before legacy budget selection.
- Pipeline stretches renderer choreography to reconciled audio duration.
- Independent **bridge V0.5 conservative dialogue guard** (6.5s+ minimum for dialogue scenes) protects rendering even if a future engine change regresses timing.
- Bridge health exposes the exact active engine file paths, SHA256 values and patch status.
- Installer validates byte equality and Python import path before reporting success.

### Better Creator Studio UI

- Quick-start templates: Local Business Reel, Kanpuri Comedy, Product Ad and YouTube Story.
- Cleaner quality-mode selection and estimated credit/safety summary.
- Scene editor + one-scene AI rewrite retained.
- Render tab now has **Repair timing + render preview** one-click workflow.
- Engine V6.6 / bridge status is visible in the project UI.
- Dashboard, media library, render gallery and diagnostics remain included.

### Local-first providers

- Ollama `llama3.2` story/scene generation.
- macOS `say` TTS through guarded host bridge.
- Automatic SRT captions and FFmpeg local previews.
- Existing Agentic Content Factory Blender engine.
- Veo/Runway remain optional/off by default.

## Install + start

See `ONE_SHOT_INSTALL.md`. Recommended command after unzip:

```bash
./install_and_start_v0_5.sh ~/Downloads/bharatvideo_ai_mvp_v0_1 /Users/maa/agentic-content-factory
```
