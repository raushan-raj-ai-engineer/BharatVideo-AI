# BharatVideo AI V0.5 Architecture

```text
Next.js Creator Studio
    |
FastAPI API
    |-- Projects / Scenes / Timing QA / Providers / Analytics
    |-- PostgreSQL
    |-- Redis + Celery
    |     |-- story planner
    |     |-- local media worker
    |     `-- Blender render worker
    |
    |-- Ollama (local story planning)
    |-- Guarded macOS Host Bridge 0.4
    |     |-- macOS say TTS
    |     `-- Agentic Content Factory / Blender
    |             `-- V6.6 actual-TTS duration self-heal
    |
    `-- Local asset storage + FFmpeg
```

## V0.5 timing safety chain

```text
Scene authoring duration
      |
API conservative timing QA
      |
Bridge transient-plan auto-fit
      |
Actual TTS WAV generation
      |
Renderer V6.6 pre-selection budget extension
      |
Complete turns preserved <= natural voice cap
      |
Renderer-only choreography duration follows audio
```

The source episode JSON remains immutable during engine self-healing.

## Provider-neutral media contract

`MediaAsset` continues to represent image, voice, subtitle, scene-video and final-video outputs. Local/free providers remain default. The `/v1/providers` endpoint exposes readiness without enabling paid services implicitly.

## Host security boundary

The bridge exposes only `/health`, `/preflight`, validated `/render`, guarded `/tts`, and bridge-created `/assets/{id}`. No arbitrary shell endpoint exists.

## Database compatibility

V0.5 does not destructively migrate existing project/scene/media tables. Timing information is computed from existing scene metadata, and the one-click auto-fit only updates `Scene.duration_seconds` when explicitly invoked.
