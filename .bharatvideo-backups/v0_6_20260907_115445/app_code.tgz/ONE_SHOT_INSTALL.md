# BharatVideo AI V0.5 — One-shot install + start

V0.5 consolidates the app, all previous render hotfixes, a self-verifying renderer V6.6 patch, a conservative host-bridge timing fallback, and the Creator Studio UI refresh.

## Recommended: one command after unzip

```bash
cd ~/Downloads
unzip -o bharatvideo_ai_mvp_v0_5.zip
cd bharatvideo_ai_mvp_v0_5
./install_and_start_v0_5.sh ~/Downloads/bharatvideo_ai_mvp_v0_1 /Users/maa/agentic-content-factory
```

The command:

- preserves `.env`, PostgreSQL data, Docker volumes, storage and existing projects;
- backs up app code plus active `audio.py` and `pipeline.py`;
- copies the exact tested renderer V6.6 files into the path used by the Blender CLI;
- verifies byte-for-byte SHA256 equality;
- proves Python imports those exact active files;
- runs the exact 3.59s voice / 3.00s scene regression test;
- rebuilds/recreates Docker services without deleting volumes;
- restarts the host bridge and verifies `bridge_version=0.5.0` and `engine_patch.active=true`.

## Render safety chain

1. App timing QA can persist recommended scene durations.
2. Bridge V0.5 applies a conservative 6.5s+ dialogue floor before Blender as an independent fallback.
3. Renderer V6.6 measures actual generated WAV duration before dialogue selection and grows the transient budget rather than exceeding the 1.15x natural speech cap.
4. Pipeline stretches renderer-only scene choreography to the reconciled audio duration.

The original project story/dialogue is not silently shortened to solve timing.
