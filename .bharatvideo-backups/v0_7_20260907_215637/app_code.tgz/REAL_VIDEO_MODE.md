# BharatVideo AI V0.6 — Real Video Mode

V0.6 changes the product default from storyboard cards to the real Blender character pipeline.

## Production path
Prompt -> LLM scene plan -> timing autofit -> Blender 3D characters -> camera/action/expression -> neural Hindi TTS -> rendered MP4.

## Draft path
The old black/white `visual.png` card pipeline remains only as an explicitly labelled Storyboard Draft for script/caption debugging. It is not the production video path.

## Voice
The installer adds `edge-tts==7.2.8` to the Agentic Content Factory Python environment and installs `scripts/bharatvideo_neural_tts.py`.
The Blender engine receives `CONTENT_FACTORY_TTS_CMD` from the host bridge, so character dialogue prefers neural Hindi speech. macOS `say` remains only a fallback.

Character profiles:
- Babuji: hi-IN-MadhurNeural, slower/lower
- Guddu: hi-IN-MadhurNeural, neutral
- Bittu: hi-IN-MadhurNeural, faster/higher
- Female/default assistant: hi-IN-SwaraNeural

This improves naturalness, but it is not a cloned native Kanpuri accent. A licensed/custom regional TTS can later replace the same command hook.
