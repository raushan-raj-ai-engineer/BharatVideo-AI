# BharatVideo AI Roadmap

## v0.1 — foundation ✅
Next.js, FastAPI, PostgreSQL, Redis/Celery, mock scene workflow.

## v0.2 — real planning + engine bridge ✅
Ollama story planning, Kanpuriya/Hinglish contracts, scene editor, scene rewrite, SSE progress, guarded Blender bridge.

## v0.3 — local media pipeline ✅
Host TTS, captions, mock visuals, FFmpeg scene videos/final local preview, provider-neutral media assets.

## v0.6 — Creator Studio + render reliability ✅
- Consolidated all 0.3.x render fixes into one release
- Engine V6.6 actual-waveform scene auto-extension
- Preserve complete dialogue turns before budget selection
- Scene timing report + one-click persisted auto-fit
- Modern Dashboard / Studio / Media / Render / Diagnostics UI
- Provider status endpoint
- Lightweight project analytics endpoint
- One-shot app + engine installer with rollback

## v0.6 — commercial controls
- Razorpay
- credit reservations/refunds and detailed usage ledger
- workspace + brand kit
- external Veo/Runway/TTS adapters
- signed asset URLs

## v0.6 — Canva-like timeline
- multi-track timeline
- clip reorder/trim/split
- scene versions
- template library
- export presets
