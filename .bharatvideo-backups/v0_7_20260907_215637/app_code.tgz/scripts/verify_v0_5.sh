#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENGINE_ROOT="${HOST_AGENTIC_CONTENT_FACTORY_ROOT:-/Users/maa/agentic-content-factory}"
PY="${ENGINE_ROOT}/.venv/bin/python"
[[ -x "$PY" ]] || PY="$(command -v python3)"

echo "[VERIFY V0.5] app version=$(cat "$ROOT/VERSION" 2>/dev/null || echo unknown)"
grep -q 'BRIDGE_VERSION = "0.5.0"' "$ROOT/engine_bridge/bridge_server.py" && echo "[VERIFY V0.5] bridge code=0.5.0 PASS"
grep -q 'VOICE PLAN AUTO-EXTEND V6.6' "$ENGINE_ROOT/src/content_factory/cartoon/blender_full/audio.py" && echo "[VERIFY V0.5] active engine audio V6.6=PASS"
grep -q 'RENDER DURATION AUTO-EXTEND V6.6' "$ENGINE_ROOT/src/content_factory/cartoon/blender_full/pipeline.py" && echo "[VERIFY V0.5] active engine pipeline V6.6=PASS"
PYTHONPATH="$ENGINE_ROOT/src" "$PY" - <<'PY'
from pathlib import Path
import content_factory.cartoon.blender_full.audio as a
import content_factory.cartoon.blender_full.pipeline as p
print('[VERIFY V0.5] imported audio=',Path(a.__file__).resolve())
print('[VERIFY V0.5] imported pipeline=',Path(p.__file__).resolve())
PY
if [[ -f "$ENGINE_ROOT/tests/test_v66_duration_autogrow.py" ]]; then
  (cd "$ENGINE_ROOT" && PYTHONPATH="$ENGINE_ROOT/src" "$PY" -m pytest -q tests/test_v66_duration_autogrow.py)
fi
if command -v docker >/dev/null 2>&1; then (cd "$ROOT" && docker compose ps) || true; fi
echo "[VERIFY V0.5] PASS"
