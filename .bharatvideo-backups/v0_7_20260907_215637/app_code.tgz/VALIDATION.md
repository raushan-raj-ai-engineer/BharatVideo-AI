# BharatVideo AI V0.6 Validation

- BharatVideo API/service regression: **17/17 PASS**
- Agentic Content Factory V6.4 baseline + V6.6 patch full regression: **90/90 PASS**
- Exact reported regression (`3.59s` generated voice inside `3.00s` authored scene, natural cap `1.15x`): **PASS**
- Bridge conservative fallback: dialogue scene `3.0s` expands to at least `6.5s`: **PASS**
- Python compile: **PASS**
- Shell syntax: **PASS**
- TS/TSX parse syntax: **PASS**
- Transactional installer simulation on V0.3 app + V6.4 engine baseline: **PASS**
- Rollback byte restoration simulation: **PASS**
- Active engine checksum verification: **PASS**
- Active Python import-path verification: **PASS**

Frontend full dependency typecheck could not be executed in the build container because npm dependency installation timed out; source parse validation passed and dependency versions remain pinned for Docker build.
