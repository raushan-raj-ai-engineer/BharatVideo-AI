import './globals.css';
import Link from 'next/link';

export const metadata = { title: 'BharatVideo AI Studio', description: 'AI video studio for Indian creators' };

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>
    <div className="appShell">
      <aside className="sidebar">
        <Link className="brand" href="/"><span className="brandMark">B</span><span>BharatVideo <b>AI</b></span></Link>
        <nav className="sideNav">
          <Link href="/">⌂ <span>Dashboard</span></Link>
          <Link href="/create">✦ <span>Create video</span></Link>
          <Link href="/projects">▣ <span>Projects</span></Link>
        </nav>
        <div className="sideFoot"><span className="statusDot"/> Local-first MVP <b>v0.5</b></div>
      </aside>
      <main className="mainArea"><div className="topbar"><div><b>Creator Studio</b><span>Indian-language AI video workflow</span></div><Link href="/create" className="topAction">+ New video</Link></div><div className="content">{children}</div></main>
    </div>
  </body></html>;
}
