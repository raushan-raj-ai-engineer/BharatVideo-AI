import importlib.util
from pathlib import Path

BRIDGE = Path(__file__).resolve().parents[3] / "engine_bridge" / "bridge_server.py"
spec = importlib.util.spec_from_file_location("bridge_server_v032", BRIDGE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def test_bridge_autofits_old_saved_plan_without_persisting_db():
    plan = {"scenes": [{
        "id": 2,
        "shot_duration_seconds": 3.0,
        "dialogue": [{"character_id": "babuji", "text": "का बे Guddua ई फोनवा में कौन अंगरेजन बैठी है हमका अभी सब सच सच बताय द्यो"}],
    }]}
    changes = mod._autofit_plan_dialogue_budgets(plan)
    assert changes
    assert plan["scenes"][0]["shot_duration_seconds"] >= 5.0
