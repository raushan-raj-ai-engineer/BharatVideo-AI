from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models import MediaAsset, Project, ProjectStatus, Scene

router = APIRouter(prefix="/v1/analytics", tags=["analytics"])

@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    projects = int(db.scalar(select(func.count()).select_from(Project)) or 0)
    scenes = int(db.scalar(select(func.count()).select_from(Scene)) or 0)
    assets = int(db.scalar(select(func.count()).select_from(MediaAsset)) or 0)
    credits = int(db.scalar(select(func.coalesce(func.sum(MediaAsset.cost_credits), 0))) or 0)
    ready = int(db.scalar(select(func.count()).select_from(Project).where(Project.status == ProjectStatus.READY)) or 0)
    return {"projects": projects, "scenes": scenes, "media_assets": assets, "credits_used": credits, "ready_projects": ready}
