# BharatVideo AI — MVP v0.3

v0.3 turns the v0.2 story/scene planner into a working **zero-paid-API local media pipeline**.

## What now works

1. Prompt -> Ollama story/scenes
2. Edit/regenerate scenes
3. Generate a local mock visual for every scene
4. Generate real macOS `say` voice through the guarded host bridge (Lekha by default)
5. Generate per-scene SRT captions
6. FFmpeg composes each image + voice into a playable scene MP4
7. FFmpeg joins scene MP4s into `final_local_preview.mp4`
8. Project UI shows generated image/audio/video assets
9. Existing Blender preview path from v0.2 remains available

No Veo/Runway key is required in v0.3.

## Upgrade the instance you already upgraded to v0.2

Stop Docker:

```bash
cd ~/Downloads/bharatvideo_ai_mvp_v0_1
docker compose down
```

If the old engine bridge is running in another terminal, stop it with `Ctrl+C` so it can be restarted with v0.3 TTS support.

Extract v0.3:

```bash
cd ~/Downloads
unzip -o bharatvideo_ai_mvp_v0_3.zip
cd bharatvideo_ai_mvp_v0_3
```

Overlay it onto your existing working directory (the directory name can still be `v0_1` because earlier upgrades were in-place):

```bash
./scripts/upgrade_from_v0_2.sh ~/Downloads/bharatvideo_ai_mvp_v0_1
```

Then restart from the existing directory:

```bash
cd ~/Downloads/bharatvideo_ai_mvp_v0_1
docker compose up --build
```

In terminal 2 restart the host bridge:

```bash
cd ~/Downloads/bharatvideo_ai_mvp_v0_1
./scripts/start_engine_bridge.sh
```

Check:

```bash
./scripts/check_media.sh
```

Open:

- Web: http://localhost:3000
- API: http://localhost:8000/docs
- Health: http://localhost:8000/health

## v0.3 UI flow

```text
Create project
  -> Generate story
  -> Edit scenes
  -> Generate local media
       visual.png
       voice.wav
       captions.srt
       scene.mp4
  -> Compose local preview
       final_local_preview.mp4
```

The **Generate local media** button may take some time because every scene gets its own TTS + FFmpeg composition job.

## Local media configuration

`.env` defaults:

```env
TTS_PROVIDER=host_say
TTS_VOICE=Lekha
TTS_SPEECH_RATE=185
IMAGE_PROVIDER=mock
FFMPEG_BINARY=ffmpeg
FFPROBE_BINARY=ffprobe
```

`host_say` runs macOS `say` on the host, not inside Docker. Therefore the host bridge must be running.

If you only want infrastructure tests and do not want speech:

```env
TTS_PROVIDER=mock
```

The mock TTS provider generates silent WAV, which keeps the FFmpeg pipeline testable.

## New API endpoints

```text
POST /v1/scenes/{scene_id}/media
POST /v1/projects/{project_id}/media
GET  /v1/projects/{project_id}/media
POST /v1/projects/{project_id}/compose
```

Existing v0.2 endpoints remain compatible.

## Storage contract

Example:

```text
/data/storage/projects/<project-id>/media/<scene-id>/visual.png
/data/storage/projects/<project-id>/media/<scene-id>/voice.wav
/data/storage/projects/<project-id>/media/<scene-id>/captions.srt
/data/storage/projects/<project-id>/media/<scene-id>/scene.mp4
/data/storage/projects/<project-id>/exports/final_local_preview.mp4
```

## Tests

```bash
cd apps/api
python -m pytest -q
```

Artifact validation result when packaged: **9 tests passed** plus Python/shell checks.

## What v0.3 deliberately does NOT do yet

- It does not call paid Veo/Runway APIs.
- Mock visual cards are placeholders, not production AI visuals.
- It does not yet implement Razorpay or real credit reservations/refunds.
- It tracks per-asset provider/cost fields, while the full billing ledger comes in v0.4.
- Final captions are generated; burn-in is attempted by FFmpeg and safely falls back to sidecar captions if the subtitle renderer cannot handle the font/filter.

## Next: v0.4

Commercial/product controls: Razorpay, credit ledger, brand kit/workspaces, usage-cost dashboard, signed storage URLs, and optional external provider adapters behind the existing MediaAsset contract.
