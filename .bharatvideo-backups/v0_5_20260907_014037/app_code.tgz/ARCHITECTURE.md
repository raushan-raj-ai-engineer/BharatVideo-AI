# BharatVideo AI v0.3 Architecture

```text
Next.js Web
    |
FastAPI API
    |-- PostgreSQL: projects, scenes, jobs, media_assets
    |-- Redis/Celery
    |       |-- story planning worker
    |       |-- media worker
    |       `-- Blender render worker/bridge client
    |
    |-- Ollama on macOS host
    |-- Guarded host bridge
    |       |-- Blender/Agentic Content Factory
    |       `-- macOS say -> WAV
    |
    `-- Local object-like storage
            |-- visual.png
            |-- voice.wav
            |-- captions.srt
            |-- scene.mp4
            `-- final_local_preview.mp4
```

## Core rule

A video is not a single generation operation. It is a versionable collection of **Scenes -> MediaAssets -> Composition**.

`MediaAsset` is the provider-neutral contract introduced in v0.3:

```text
kind: image | voice | subtitle | scene_video | final_video
provider: mock | host_say | ffmpeg | future external provider
status: QUEUED | GENERATING | READY | FAILED
cost_credits: integer
metadata_json: provider-specific details
```

The free local path intentionally uses mock visuals and macOS speech so the product workflow can be developed without paid API spend. Veo/Runway/other providers should later implement the same asset contract rather than changing the project/scene model.

## Host boundary

Docker does not execute arbitrary commands on the Mac. The host bridge exposes only guarded operations:

- `/health`
- `/preflight`
- validated `/render`
- validated `/tts`
- `/assets/{id}` for bridge-created artifacts

No arbitrary shell command endpoint exists.

## Database compatibility

v0.3 adds `media_assets` only. Existing v0.2 project/scene/job/artifact tables are not destructively changed. The API startup `create_all` creates the new table in the existing PostgreSQL volume.
