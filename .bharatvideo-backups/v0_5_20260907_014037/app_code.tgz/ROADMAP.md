# BharatVideo AI Roadmap

## v0.1 — foundation ✅
- Next.js + FastAPI
- PostgreSQL
- Redis/Celery
- mock scene workflow

## v0.2 — real planning + engine bridge ✅
- local Ollama story generation
- Hindi/Hinglish/Kanpuriya planning contract
- scene editor
- single-scene AI rewrite
- SSE job progress
- Agentic Content Factory plan export
- guarded Blender host bridge
- preview artifact in UI

## v0.3 — local media pipeline ✅
- TTS provider routing (`host_say` or `mock`)
- guarded macOS `say` endpoint on the host bridge
- image provider routing with a zero-cost mock visual provider
- per-scene image / voice / subtitle / scene-video assets
- scene-level and project-level media jobs
- SRT subtitle generation
- FFmpeg scene composition and final local preview
- optional subtitle burn-in with safe fallback
- per-asset provider/status/cost metadata
- v0.2-compatible database upgrade (new table only)

## v0.4 — commercial controls
- Razorpay
- credit ledger/reservations/refunds
- workspace + brand kit
- usage/cost dashboard
- signed asset URLs
- external TTS/image/video provider adapters

## v0.5 — Canva-like editor foundation
- timeline tracks
- clip trim/reorder
- scene versions
- template library
- export presets
