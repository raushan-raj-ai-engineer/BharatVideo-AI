#!/usr/bin/env python3
"""Minimal guarded host bridge for the existing Agentic Content Factory.

Runs on macOS host so Blender/Homebrew tools remain available. Docker workers call
it through host.docker.internal. No arbitrary shell command is accepted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import threading
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


class BridgeConfig:
    def __init__(self, repo_root: Path, token: str):
        self.repo_root = repo_root.resolve()
        self.token = token
        self.asset_dir = Path(tempfile.gettempdir()) / "bharatvideo_engine_bridge_assets"
        self.asset_dir.mkdir(parents=True, exist_ok=True)
        self.assets: dict[str, Path] = {}
        self.lock = threading.Lock()

    def python(self) -> str:
        candidates = [
            self.repo_root / ".venv/bin/python",
            self.repo_root / "venv/bin/python",
        ]
        for item in candidates:
            if item.is_file():
                return str(item)
        found = shutil.which("python3")
        if not found:
            raise RuntimeError("No Python interpreter found for Agentic Content Factory")
        return found

    def base_env(self) -> dict[str, str]:
        env = os.environ.copy()
        src = str(self.repo_root / "src")
        env["PYTHONPATH"] = src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        return env


CONFIG: BridgeConfig


def _json(handler: BaseHTTPRequestHandler, status: int, payload: dict):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def _newest_mp4(root: Path) -> Path | None:
    files = [p for p in root.rglob("*.mp4") if p.is_file()]
    return max(files, key=lambda p: p.stat().st_mtime) if files else None


class Handler(BaseHTTPRequestHandler):
    server_version = "BharatVideoEngineBridge/0.2"

    def log_message(self, fmt, *args):
        print(f"[ENGINE BRIDGE] {self.address_string()} - {fmt % args}")

    def authorized(self) -> bool:
        return self.headers.get("X-BharatVideo-Bridge-Token", "") == CONFIG.token

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length <= 0 or length > 2_000_000:
            raise ValueError("Invalid request body size")
        raw = self.rfile.read(length)
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("JSON root must be an object")
        return data

    def do_GET(self):
        if not self.authorized():
            return _json(self, HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
        path = urlparse(self.path).path
        if path == "/health":
            try:
                py = CONFIG.python()
                return _json(self, HTTPStatus.OK, {
                    "status": "ok",
                    "bridge_version": "0.2.0",
                    "repo_root": str(CONFIG.repo_root),
                    "python": py,
                    "repo_exists": CONFIG.repo_root.is_dir(),
                })
            except Exception as exc:
                return _json(self, HTTPStatus.SERVICE_UNAVAILABLE, {"status": "error", "error": str(exc)})
        if path.startswith("/assets/"):
            asset_id = path.rsplit("/", 1)[-1]
            with CONFIG.lock:
                file_path = CONFIG.assets.get(asset_id)
            if not file_path or not file_path.is_file():
                return _json(self, HTTPStatus.NOT_FOUND, {"error": "asset not found"})
            content = file_path.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Length", str(len(content)))
            self.send_header("X-Content-SHA256", hashlib.sha256(content).hexdigest())
            self.end_headers()
            self.wfile.write(content)
            return
        return _json(self, HTTPStatus.NOT_FOUND, {"error": "not found"})

    def do_POST(self):
        if not self.authorized():
            return _json(self, HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
        path = urlparse(self.path).path
        try:
            if path == "/preflight":
                cmd = [
                    CONFIG.python(), "-m", "content_factory.cartoon.blender_full.cli",
                    "--project", str(CONFIG.repo_root), "--check-only",
                ]
                proc = subprocess.run(
                    cmd, cwd=CONFIG.repo_root, env=CONFIG.base_env(),
                    text=True, capture_output=True, timeout=180,
                )
                return _json(self, HTTPStatus.OK if proc.returncode == 0 else HTTPStatus.BAD_GATEWAY, {
                    "status": "ok" if proc.returncode == 0 else "failed",
                    "returncode": proc.returncode,
                    "stdout": proc.stdout[-8000:],
                    "stderr": proc.stderr[-8000:],
                })

            if path == "/render":
                data = self.read_json()
                plan = data.get("plan")
                if not isinstance(plan, dict) or not isinstance(plan.get("scenes"), list) or not plan["scenes"]:
                    raise ValueError("plan.scenes must be a non-empty list")
                if len(plan["scenes"]) > 40:
                    raise ValueError("Bridge refuses plans above 40 scenes")
                quality = str(data.get("quality") or "draft")
                if quality not in {"draft", "standard", "high"}:
                    raise ValueError("invalid quality")
                max_scenes = data.get("max_scenes")
                if max_scenes is not None:
                    max_scenes = int(max_scenes)
                    if not 1 <= max_scenes <= 12:
                        raise ValueError("max_scenes must be 1..12 or null")

                render_id = str(uuid.uuid4())
                work_dir = Path(tempfile.gettempdir()) / f"bharatvideo_render_{render_id}"
                output_dir = work_dir / "output"
                output_dir.mkdir(parents=True, exist_ok=True)
                plan_path = work_dir / "episode_plan.json"
                plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

                cmd = [
                    CONFIG.python(), "-m", "content_factory.cartoon.blender_full.cli",
                    "--project", str(CONFIG.repo_root),
                    "--render-plan", str(plan_path),
                    "--output-dir", str(output_dir),
                    "--quality", quality,
                    "--fresh",
                ]
                if max_scenes is not None:
                    cmd += ["--max-scenes", str(max_scenes)]
                proc = subprocess.run(
                    cmd, cwd=CONFIG.repo_root, env=CONFIG.base_env(),
                    text=True, capture_output=True,
                )
                if proc.returncode != 0:
                    return _json(self, HTTPStatus.BAD_GATEWAY, {
                        "status": "failed", "returncode": proc.returncode,
                        "stdout": proc.stdout[-12000:], "stderr": proc.stderr[-12000:],
                    })
                mp4 = _newest_mp4(output_dir)
                if not mp4:
                    return _json(self, HTTPStatus.BAD_GATEWAY, {
                        "status": "failed", "error": "Renderer completed but no MP4 was found",
                        "stdout": proc.stdout[-12000:], "stderr": proc.stderr[-12000:],
                    })
                stable = CONFIG.asset_dir / f"{render_id}.mp4"
                shutil.copy2(mp4, stable)
                with CONFIG.lock:
                    CONFIG.assets[render_id] = stable
                return _json(self, HTTPStatus.OK, {
                    "status": "succeeded",
                    "asset_id": render_id,
                    "output_file": str(mp4),
                    "size_bytes": stable.stat().st_size,
                    "stdout_tail": proc.stdout[-4000:],
                })
        except (ValueError, json.JSONDecodeError) as exc:
            return _json(self, HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except Exception as exc:
            return _json(self, HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
        return _json(self, HTTPStatus.NOT_FOUND, {"error": "not found"})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=os.getenv("HOST_AGENTIC_CONTENT_FACTORY_ROOT", "/Users/maa/agentic-content-factory"))
    parser.add_argument("--token", default=os.getenv("ENGINE_BRIDGE_TOKEN", "change-me-local-dev-token"))
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8090)
    args = parser.parse_args()

    global CONFIG
    CONFIG = BridgeConfig(Path(args.repo).expanduser(), args.token)
    if not CONFIG.repo_root.is_dir():
        raise SystemExit(f"Repo not found: {CONFIG.repo_root}")
    print(f"[ENGINE BRIDGE] repo={CONFIG.repo_root}")
    print(f"[ENGINE BRIDGE] listening=http://{args.host}:{args.port}")
    print("[ENGINE BRIDGE] only /health, /preflight and validated /render are allowed")
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
