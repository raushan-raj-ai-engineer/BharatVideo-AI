import Link from 'next/link';

export default function Home(){return <>
  <section className="hero"><span className="pill">MVP v0.2</span><h1>Prompt → real AI story → editable scenes → Blender preview.</h1><p className="muted">Ollama-first local planning keeps development cost at zero. Scene-level editing and a guarded host bridge connect the web app to your existing Agentic Content Factory.</p></section>
  <div className="grid two"><div className="card"><h2>Create a video</h2><p>Generate Hindi, Hinglish or Kanpuriya story beats with a real local LLM.</p><Link href="/create"><button>New AI project</button></Link></div><div className="card"><h2>Scene-level control</h2><p>Rewrite one punchline, visual or generation mode without throwing away the rest of the project.</p><Link href="/projects"><button className="secondary">Open projects</button></Link></div></div>
</>}
