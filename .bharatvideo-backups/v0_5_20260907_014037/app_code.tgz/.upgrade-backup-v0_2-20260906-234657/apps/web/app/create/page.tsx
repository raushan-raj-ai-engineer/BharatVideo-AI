'use client';

import {FormEvent, useState} from 'react';
import {useRouter} from 'next/navigation';

const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';

export default function CreatePage(){
  const [msg,setMsg]=useState('');
  const [busy,setBusy]=useState(false);
  const router=useRouter();

  async function submit(e:FormEvent<HTMLFormElement>){
    e.preventDefault();
    setBusy(true); setMsg('');
    const fd=new FormData(e.currentTarget);
    const payload={
      title:String(fd.get('title')),
      prompt:String(fd.get('prompt')),
      platform:String(fd.get('platform')),
      language:String(fd.get('language')),
      dialect:String(fd.get('dialect')),
      duration_seconds:Number(fd.get('duration_seconds')),
      quality:String(fd.get('quality')),
      style:String(fd.get('style')),
      aspect_ratio:String(fd.get('aspect_ratio')),
    };
    try{
      const r=await fetch(`${API}/v1/projects`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const project=await r.json();
      if(!r.ok) throw new Error(JSON.stringify(project));
      const j=await fetch(`${API}/v1/projects/${project.id}/generate`,{method:'POST'});
      const job=await j.json();
      if(!j.ok) throw new Error(JSON.stringify(job));
      router.push(`/projects/${project.id}?job=${job.id}`);
    }catch(err){setMsg(`Error: ${String(err)}`)}finally{setBusy(false)}
  }

  return <div className="card">
    <span className="pill">MVP v0.2 • Real LLM planning</span>
    <h1>Create AI Video</h1>
    <form className="grid" onSubmit={submit}>
      <input name="title" required placeholder="Project title" defaultValue="Kanpuri Restaurant Reel"/>
      <textarea name="prompt" required placeholder="Describe the video..." defaultValue="Babuji discovers an AI ordering kiosk at a Kanpur restaurant and thinks it is the new manager. Make it fast, funny and end with a twist."/>
      <div className="row">
        <select name="platform" defaultValue="instagram_reel"><option value="instagram_reel">Instagram Reel</option><option value="youtube_short">YouTube Short</option><option value="youtube">YouTube</option></select>
        <select name="aspect_ratio" defaultValue="9:16"><option value="9:16">Vertical 9:16</option><option value="16:9">Landscape 16:9</option></select>
      </div>
      <div className="row">
        <select name="language" defaultValue="hi-IN"><option value="hi-IN">Hindi</option><option value="en-IN">English India</option></select>
        <select name="dialect" defaultValue="kanpuriya"><option value="kanpuriya">Kanpuriya</option><option value="hinglish">Hinglish</option><option value="standard_hindi">Standard Hindi</option></select>
      </div>
      <div className="row">
        <select name="style" defaultValue="kanpuri_comedy"><option value="kanpuri_comedy">Kanpuri Comedy</option><option value="business_funny">Business Funny</option><option value="product_ad">Product Ad</option><option value="creator_story">Creator Story</option></select>
        <select name="quality" defaultValue="balanced"><option value="economy">Economy</option><option value="balanced">Balanced</option><option value="premium">Premium</option></select>
      </div>
      <input name="duration_seconds" type="number" min="5" max="600" defaultValue="30"/>
      <button disabled={busy}>{busy?'Creating story job...':'Generate story + scenes'}</button>
      {msg&&<p className="error">{msg}</p>}
    </form>
  </div>
}
