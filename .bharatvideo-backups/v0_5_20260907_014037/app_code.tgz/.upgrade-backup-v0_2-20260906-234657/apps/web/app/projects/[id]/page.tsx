'use client';

import {use, useCallback, useEffect, useMemo, useState} from 'react';
import {useSearchParams} from 'next/navigation';

const API=process.env.NEXT_PUBLIC_API_BASE_URL||'http://localhost:8000';

type Scene={id:string;order_index:number;duration_seconds:number;dialogue:string;visual_prompt:string;generation_mode:string;asset_url?:string|null;metadata_json?:Record<string,any>};
type Artifact={id:string;kind:string;url:string;metadata_json?:Record<string,any>};
type Project={id:string;title:string;prompt:string;platform:string;language:string;dialect:string;style:string;duration_seconds:number;quality:string;status:string;estimated_credits:number;scenes:Scene[];artifacts:Artifact[]};

type JobEvent={id:string;status:string;progress:number;stage:string;error?:string|null};

function SceneCard({scene,onChanged}:{scene:Scene;onChanged:()=>void}){
  const [dialogue,setDialogue]=useState(scene.dialogue);
  const [visual,setVisual]=useState(scene.visual_prompt);
  const [mode,setMode]=useState(scene.generation_mode);
  const [instruction,setInstruction]=useState('Make the punchline stronger and add a clearer physical action.');
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState('');

  useEffect(()=>{setDialogue(scene.dialogue);setVisual(scene.visual_prompt);setMode(scene.generation_mode)},[scene]);

  async function save(){
    setBusy(true); setMessage('');
    try{
      const r=await fetch(`${API}/v1/scenes/${scene.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({dialogue,visual_prompt:visual,generation_mode:mode})});
      const body=await r.json(); if(!r.ok) throw new Error(JSON.stringify(body));
      setMessage('Saved'); onChanged();
    }catch(e){setMessage(`Error: ${String(e)}`)}finally{setBusy(false)}
  }

  async function regenerate(){
    setBusy(true); setMessage('AI rewriting scene...');
    try{
      const r=await fetch(`${API}/v1/scenes/${scene.id}/regenerate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({instruction})});
      const body=await r.json(); if(!r.ok) throw new Error(JSON.stringify(body));
      setDialogue(body.dialogue); setVisual(body.visual_prompt); setMode(body.generation_mode); setMessage('AI rewrite complete'); onChanged();
    }catch(e){setMessage(`Error: ${String(e)}`)}finally{setBusy(false)}
  }

  return <div className="card sceneCard">
    <div className="sceneHeader"><div><span className="pill">Scene {scene.order_index+1}</span><h3>{scene.metadata_json?.setup||`Scene ${scene.order_index+1}`}</h3></div><div><b>{scene.duration_seconds.toFixed(1)}s</b></div></div>
    <label>Dialogue</label><textarea value={dialogue} onChange={e=>setDialogue(e.target.value)}/>
    <label>Visual prompt</label><textarea className="smallArea" value={visual} onChange={e=>setVisual(e.target.value)}/>
    <div className="row"><select value={mode} onChange={e=>setMode(e.target.value)}><option>BLENDER_3D</option><option>TEMPLATE</option><option>AI_IMAGE</option><option>AI_VIDEO</option></select><button disabled={busy} onClick={save}>Save scene</button></div>
    <div className="aiRewrite"><input value={instruction} onChange={e=>setInstruction(e.target.value)}/><button className="secondary" disabled={busy} onClick={regenerate}>✨ AI Regenerate</button></div>
    {message&&<p className={message.startsWith('Error')?'error':'success'}>{message}</p>}
  </div>
}

export default function ProjectDetail({params}:{params:Promise<{id:string}>}){
  const {id}=use(params);
  const search=useSearchParams();
  const [project,setProject]=useState<Project|null>(null);
  const [error,setError]=useState('');
  const [job,setJob]=useState<JobEvent|null>(null);
  const [engine,setEngine]=useState<any>(null);
  const [busy,setBusy]=useState(false);

  const load=useCallback(async()=>{
    try{const r=await fetch(`${API}/v1/projects/${id}`,{cache:'no-store'});const body=await r.json();if(!r.ok)throw new Error(JSON.stringify(body));setProject(body);setError('')}catch(e){setError(String(e))}
  },[id]);

  useEffect(()=>{load()},[load]);

  const watchJob=useCallback((jobId:string)=>{
    setJob({id:jobId,status:'QUEUED',progress:0,stage:'queued'});
    const es=new EventSource(`${API}/v1/jobs/${jobId}/events`);
    es.addEventListener('progress',(event:any)=>{
      const payload=JSON.parse(event.data) as JobEvent; setJob(payload);
      if(payload.status==='SUCCEEDED'||payload.status==='FAILED'){es.close();load()}
    });
    es.onerror=()=>{es.close()};
    return es;
  },[load]);

  useEffect(()=>{const initial=search.get('job');if(initial){const es=watchJob(initial);return()=>es.close()}},[search,watchJob]);

  async function generateAgain(){setBusy(true);try{const r=await fetch(`${API}/v1/projects/${id}/generate`,{method:'POST'});const body=await r.json();if(!r.ok)throw new Error(JSON.stringify(body));watchJob(body.id)}catch(e){setError(String(e))}finally{setBusy(false)}}
  async function renderPreview(){setBusy(true);try{const r=await fetch(`${API}/v1/projects/${id}/render`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'preview',quality:'draft'})});const body=await r.json();if(!r.ok)throw new Error(JSON.stringify(body));watchJob(body.id)}catch(e){setError(String(e))}finally{setBusy(false)}}
  async function engineHealth(){try{const bridge=await fetch(`${API}/v1/engine/health`);const bridgeBody=await bridge.json();if(!bridge.ok)throw new Error(bridgeBody.detail||JSON.stringify(bridgeBody));const r=await fetch(`${API}/v1/engine/preflight`,{method:'POST'});const body=await r.json();setEngine({bridge:bridgeBody,preflight:body});if(!r.ok)throw new Error(body.detail||JSON.stringify(body))}catch(e){setEngine({status:'error',error:String(e)})}}

  const planner=useMemo(()=>project?.scenes?.[0]?.metadata_json||{},[project]);
  if(!project)return <div className="card"><p>{error||'Loading project...'}</p></div>;

  return <div className="grid detailGrid">
    <section className="card projectHero">
      <div className="pageTitle"><div><span className="pill">{project.status}</span><h1>{project.title}</h1></div><div><b>{project.estimated_credits} credits est.</b></div></div>
      <p>{project.prompt}</p>
      <div className="stats"><div><b>{project.scenes.length}</b><span>Scenes</span></div><div><b>{project.duration_seconds}s</b><span>Target</span></div><div><b>{planner.planner_provider||'—'}</b><span>Planner</span></div><div><b>{planner.planner_model||'—'}</b><span>Model</span></div></div>
      {planner.planner_fallback_used&&<p className="warning">Fallback planner was used: {planner.planner_fallback_reason||'LLM provider disabled/unavailable'}</p>}
      {planner.story_hook&&<p><b>Hook:</b> {planner.story_hook}</p>}
      {planner.running_joke&&<p><b>Running joke:</b> {planner.running_joke}</p>}
      {planner.twist&&<p><b>Twist:</b> {planner.twist}</p>}
      <div className="actionRow"><button disabled={busy} onClick={generateAgain}>✨ Regenerate story</button><button className="secondary" disabled={busy||project.scenes.length===0} onClick={renderPreview}>🎬 Render 3-scene Blender preview</button><button className="ghost" onClick={engineHealth}>Check engine</button></div>
      {engine&&<pre className="miniLog">{JSON.stringify(engine,null,2)}</pre>}
      {job&&<div className="progressWrap"><div className="progressText"><span>{job.stage}</span><b>{job.progress}%</b></div><div className="progress"><div style={{width:`${job.progress}%`}}/></div>{job.error&&<p className="error">{job.error}</p>}</div>}
      {error&&<p className="error">{error}</p>}
    </section>

    {project.artifacts?.length>0&&<section className="card"><h2>Generated renders</h2><div className="grid two">{project.artifacts.map(a=><div key={a.id}><span className="pill">{a.kind}</span><video className="video" controls src={a.url}/></div>)}</div></section>}

    <section><div className="sectionTitle"><h2>Scene Editor</h2><span className="muted">Edit one scene without regenerating the whole project.</span></div><div className="grid">{project.scenes.map(s=><SceneCard key={s.id} scene={s} onChanged={load}/>)}</div></section>
  </div>
}
