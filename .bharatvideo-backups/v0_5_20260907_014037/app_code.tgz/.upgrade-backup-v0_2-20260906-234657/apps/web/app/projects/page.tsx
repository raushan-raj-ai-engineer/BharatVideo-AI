import Link from 'next/link';

const API=process.env.NEXT_PUBLIC_API_BASE_URL||'http://localhost:8000';
async function getProjects(){try{const r=await fetch(`${API}/v1/projects`,{cache:'no-store'}); if(!r.ok)return []; return r.json();}catch{return []}}

export default async function Projects(){
  const projects=await getProjects();
  return <>
    <div className="pageTitle"><div><span className="pill">v0.2</span><h1>Projects</h1></div><Link href="/create"><button className="buttonAuto">New project</button></Link></div>
    <div className="grid">
      {projects.length===0&&<div className="card"><p className="muted">No projects yet.</p></div>}
      {projects.map((p:any)=><Link key={p.id} href={`/projects/${p.id}`}><div className="card projectCard">
        <div className="row"><div><h3>{p.title}</h3><p className="muted">{p.platform} • {p.language}/{p.dialect} • {p.duration_seconds}s</p></div><div><span className="pill">{p.status}</span><p>{p.estimated_credits} credits</p></div></div>
        <p>{p.prompt}</p><p><b>{p.scenes?.length||0}</b> scenes • <b>{p.artifacts?.length||0}</b> renders</p>
      </div></Link>)}
    </div>
  </>
}
