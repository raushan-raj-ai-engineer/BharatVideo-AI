import os
import sys
import types
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:///./test_bharatvideo_v02.db"
os.environ["REDIS_URL"] = "redis://localhost:6379/15"
os.environ["LOCAL_STORAGE_DIR"] = "./test_storage_v02"
os.environ["LLM_PROVIDER"] = "mock"
os.environ["ENGINE_MODE"] = "disabled"

# The production Docker image installs Celery. The artifact-validation runtime may not.
# Use a tiny test-only import stub when Celery is absent so API/model tests remain runnable.
try:
    import celery as _celery  # noqa: F401
except ModuleNotFoundError:
    fake = types.ModuleType("celery")
    class _Celery:
        def __init__(self, *args, **kwargs):
            self.conf = types.SimpleNamespace()
        def task(self, *args, **kwargs):
            def deco(fn):
                fn.delay = lambda *a, **k: types.SimpleNamespace(id="test-task")
                return fn
            return deco
    fake.Celery = _Celery
    sys.modules["celery"] = fake


def pytest_sessionfinish(session, exitstatus):
    Path("test_bharatvideo_v02.db").unlink(missing_ok=True)
