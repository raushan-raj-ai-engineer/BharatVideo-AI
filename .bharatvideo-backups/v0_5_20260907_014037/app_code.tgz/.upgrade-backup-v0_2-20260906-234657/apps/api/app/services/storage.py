from pathlib import Path
from app.core.config import get_settings


class LocalStorage:
    def __init__(self):
        settings = get_settings()
        self.root = Path(settings.local_storage_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.base_url = settings.public_asset_base_url.rstrip("/")

    def _path(self, key: str) -> Path:
        clean = key.lstrip("/").replace("..", "_")
        path = self.root / clean
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def write_text_asset(self, key: str, content: str) -> str:
        path = self._path(key)
        path.write_text(content, encoding="utf-8")
        return f"{self.base_url}/{key.lstrip('/')}"

    def write_bytes_asset(self, key: str, content: bytes) -> str:
        path = self._path(key)
        path.write_bytes(content)
        return f"{self.base_url}/{key.lstrip('/')}"
