from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from app.core.config import get_settings
from app.services.llm import LLMError, chat_json


@dataclass(slots=True)
class PlannedScene:
    order_index: int
    duration_seconds: float
    dialogue: str
    visual_prompt: str
    generation_mode: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PlannedStory:
    title: str
    hook: str
    running_joke: str
    twist: str
    characters: list[str]
    scenes: list[PlannedScene]
    provider: str
    model: str
    fallback_used: bool = False
    fallback_reason: str | None = None


class DialogueTurn(BaseModel):
    speaker: str = Field(min_length=1, max_length=50)
    text: str = Field(min_length=1, max_length=500)
    emotion: str = "neutral"
    pose: str = "idle"


class LLMScene(BaseModel):
    duration_seconds: float = Field(ge=2, le=20)
    setup: str = ""
    dialogue: list[DialogueTurn] = Field(default_factory=list)
    visual_prompt: str = Field(min_length=5, max_length=1200)
    generation_mode: str = "BLENDER_3D"
    camera: str = "speaker_medium"
    visual_action: str = "dialogue"
    props: list[str] = Field(default_factory=list)


class LLMStory(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    hook: str = ""
    running_joke: str = ""
    twist: str = ""
    characters: list[str] = Field(default_factory=list)
    scenes: list[LLMScene] = Field(min_length=3, max_length=40)


def _scene_count(duration_seconds: int) -> int:
    # Reels/Shorts need rapid 5-7s beats; long-form cartoons use ~13.3s shots.
    if duration_seconds <= 90:
        return max(3, min(15, math.ceil(duration_seconds / 6)))
    return max(8, min(36, math.ceil(duration_seconds / 13.33)))


def _dialect_contract(language: str, dialect: str) -> str:
    if dialect.lower() == "kanpuriya":
        return (
            "Use natural, understandable Kanpuriya Hindi grammar and rhythm throughout, not standard Hindi "
            "with a few slang words. Prefer forms like 'का बे', 'हम बताय दे रहे हैं', 'काहे', 'करत हो', "
            "and situation-appropriate Kanpuriya punchlines. Keep it family-safe and widely understandable."
        )
    if dialect.lower() == "hinglish":
        return "Use natural urban Indian Hinglish, concise spoken lines, not formal translated Hindi."
    return f"Write natural spoken dialogue for language={language}, dialect={dialect}."


def _system_prompt() -> str:
    return """You are the story and scene-planning engine for BharatVideo AI.
Return ONLY valid JSON. Never use markdown fences.
Make the video immediately engaging, visually producible, and concise.
Each scene must advance the story. Avoid filler and dead air.
For comedy, create escalating misunderstandings, physical actions and a final twist.
The output schema is:
{
  "title": "...",
  "hook": "...",
  "running_joke": "...",
  "twist": "...",
  "characters": ["..."],
  "scenes": [
    {
      "duration_seconds": 6,
      "setup": "what physically happens",
      "dialogue": [{"speaker":"name","text":"line","emotion":"shocked","pose":"pointing"}],
      "visual_prompt": "visual description",
      "generation_mode": "BLENDER_3D",
      "camera": "speaker_medium",
      "visual_action": "point_phone",
      "props": ["phone"]
    }
  ]
}
Allowed generation_mode values: BLENDER_3D, AI_VIDEO, AI_IMAGE, TEMPLATE.
For low-cost MVP planning, prefer BLENDER_3D or TEMPLATE unless an AI cinematic shot is clearly valuable.
"""


def _mock_story(prompt: str, duration_seconds: int, language: str, dialect: str) -> PlannedStory:
    count = _scene_count(duration_seconds)
    per_scene = duration_seconds / count
    scenes: list[PlannedScene] = []
    for i in range(count):
        text = f"Scene {i + 1}: {prompt[:110]}"
        scenes.append(
            PlannedScene(
                order_index=i,
                duration_seconds=round(per_scene, 2),
                dialogue=text,
                visual_prompt=f"{prompt}. Beat {i + 1}. Language={language}; dialect={dialect}.",
                generation_mode="TEMPLATE",
                metadata={
                    "setup": f"Deterministic fallback beat {i + 1}",
                    "camera": "speaker_medium",
                    "visual_action": "dialogue",
                    "props": [],
                    "dialogue_turns": [{"speaker": "narrator", "text": text, "emotion": "neutral", "pose": "idle"}],
                },
            )
        )
    return PlannedStory(
        title=prompt[:80] or "BharatVideo Project",
        hook="Fast opening hook",
        running_joke="",
        twist="",
        characters=[],
        scenes=scenes,
        provider="mock",
        model="deterministic-v0.2",
        fallback_used=True,
    )


def plan_story(prompt: str, duration_seconds: int, language: str, dialect: str, style: str) -> PlannedStory:
    settings = get_settings()
    if settings.llm_provider.lower() == "mock":
        return _mock_story(prompt, duration_seconds, language, dialect)

    count = _scene_count(duration_seconds)
    user_prompt = f"""Create a video plan.
User idea: {prompt}
Target total duration: {duration_seconds} seconds
Target number of scenes: exactly {count}
Language: {language}
Dialect: {dialect}
Style: {style}
Platform pacing: hook in scene 1, strong pattern interrupt every 2-3 scenes, twist/payoff at the end.
{_dialect_contract(language, dialect)}
Keep the SUM of scene duration_seconds close to {duration_seconds} seconds.
"""
    try:
        result = chat_json(_system_prompt(), user_prompt)
        story = LLMStory.model_validate(result.data)
        if len(story.scenes) != count:
            # Accept close model output, but normalize total duration below.
            if not 3 <= len(story.scenes) <= 40:
                raise LLMError(f"LLM returned unusable scene count: {len(story.scenes)}")

        raw_total = sum(scene.duration_seconds for scene in story.scenes) or 1.0
        scale = duration_seconds / raw_total
        planned: list[PlannedScene] = []
        for idx, scene in enumerate(story.scenes):
            turns = [turn.model_dump() for turn in scene.dialogue]
            dialogue = "\n".join(f"{turn.speaker}: {turn.text}" for turn in scene.dialogue).strip()
            planned.append(
                PlannedScene(
                    order_index=idx,
                    duration_seconds=round(max(2.0, scene.duration_seconds * scale), 2),
                    dialogue=dialogue,
                    visual_prompt=scene.visual_prompt,
                    generation_mode=scene.generation_mode.upper(),
                    metadata={
                        "setup": scene.setup,
                        "camera": scene.camera,
                        "visual_action": scene.visual_action,
                        "props": scene.props,
                        "dialogue_turns": turns,
                        "story_hook": story.hook,
                        "running_joke": story.running_joke,
                        "twist": story.twist,
                    },
                )
            )
        return PlannedStory(
            title=story.title,
            hook=story.hook,
            running_joke=story.running_joke,
            twist=story.twist,
            characters=story.characters,
            scenes=planned,
            provider=result.provider,
            model=result.model,
        )
    except (LLMError, ValidationError, ValueError, json.JSONDecodeError) as exc:
        if not settings.llm_fallback_to_mock:
            raise
        fallback = _mock_story(prompt, duration_seconds, language, dialect)
        fallback.fallback_reason = str(exc)
        return fallback


def regenerate_scene_content(
    *, prompt: str, language: str, dialect: str, style: str, current_scene: dict[str, Any], instruction: str
) -> PlannedScene:
    settings = get_settings()
    if settings.llm_provider.lower() == "mock":
        updated = PlannedScene(**current_scene)
        updated.dialogue = f"{updated.dialogue}\n[Mock rewrite] {instruction}".strip()
        return updated

    schema = """Return ONLY JSON with keys: duration_seconds, setup, dialogue, visual_prompt,
generation_mode, camera, visual_action, props. dialogue is an array of objects with speaker,text,emotion,pose."""
    user = f"""Rewrite ONE scene while preserving story continuity.
Overall project: {prompt}
Language={language}; dialect={dialect}; style={style}
{_dialect_contract(language, dialect)}
Instruction: {instruction or 'Make this scene stronger and more engaging.'}
Current scene JSON: {json.dumps(current_scene, ensure_ascii=False)}
{schema}
"""
    result = chat_json("You rewrite exactly one video scene. Return only the requested JSON object and no markdown.", user)
    scene = LLMScene.model_validate(result.data)
    turns = [turn.model_dump() for turn in scene.dialogue]
    return PlannedScene(
        order_index=int(current_scene["order_index"]),
        duration_seconds=scene.duration_seconds,
        dialogue="\n".join(f"{x.speaker}: {x.text}" for x in scene.dialogue),
        visual_prompt=scene.visual_prompt,
        generation_mode=scene.generation_mode.upper(),
        metadata={
            "setup": scene.setup,
            "camera": scene.camera,
            "visual_action": scene.visual_action,
            "props": scene.props,
            "dialogue_turns": turns,
            "regenerated_by": result.provider,
            "regenerated_model": result.model,
        },
    )
