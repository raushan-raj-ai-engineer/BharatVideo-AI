import asyncio
import json

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.session import SessionLocal, get_db
from app.models import GenerationJob
from app.schemas.project import JobRead

router = APIRouter(prefix="/v1/jobs", tags=["jobs"])


def _stage(progress: int, status: str) -> str:
    value = str(status)
    if "FAILED" in value:
        return "failed"
    if "SUCCEEDED" in value:
        return "complete"
    if progress < 10:
        return "queued"
    if progress < 35:
        return "planning"
    if progress < 90:
        return "building_scenes_or_rendering"
    return "finalizing"


@router.get("/{job_id}", response_model=JobRead)
def get_job(job_id: str, db: Session = Depends(get_db)):
    job = db.get(GenerationJob, job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job


@router.get("/{job_id}/events")
def stream_job(job_id: str):
    async def events():
        previous = None
        while True:
            db = SessionLocal()
            try:
                job = db.get(GenerationJob, job_id)
                if not job:
                    yield "event: error\ndata: {\"error\":\"Job not found\"}\n\n"
                    return
                payload = {
                    "id": job.id,
                    "status": job.status.value if hasattr(job.status, "value") else str(job.status),
                    "progress": job.progress,
                    "stage": _stage(job.progress, job.status),
                    "error": job.error,
                }
            finally:
                db.close()
            serialized = json.dumps(payload)
            if serialized != previous:
                yield f"event: progress\ndata: {serialized}\n\n"
                previous = serialized
            if payload["status"] in {"SUCCEEDED", "FAILED"}:
                return
            await asyncio.sleep(0.75)

    return StreamingResponse(events(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})
