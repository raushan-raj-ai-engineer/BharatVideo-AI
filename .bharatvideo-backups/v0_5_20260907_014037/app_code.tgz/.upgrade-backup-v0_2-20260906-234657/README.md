# BharatVideo AI — MVP v0.2

v0.2 upgrades the running v0.1 scaffold from mock-only planning to a working **local LLM story/scene workflow** and adds the first safe bridge to the existing Blender content engine.

## What is new

- Real story + scene planning through local Ollama (`llama3.2` by default)
- Strong Hindi/Hinglish/Kanpuriya prompt contract
- Deterministic fallback if Ollama is unavailable (visible in the UI, not hidden)
- Project detail screen with hook/running-joke/twist metadata
- Scene editor: dialogue, visual prompt and generation mode
- Single-scene AI regeneration
- Server-Sent Events job progress
- Agentic Content Factory compatible episode-plan export
- Guarded macOS host bridge for actual Blender preview rendering
- Render artifacts copied back into BharatVideo storage and shown in the browser
- Backward-compatible v0.1 PostgreSQL enum contract

## Upgrade the v0.1 instance that is already running

Stop v0.1 first:

```bash
cd ~/Downloads/bharatvideo_ai_mvp_v0_1
docker compose down
```

Unzip v0.2 next to it:

```bash
cd ~/Downloads
unzip -o bharatvideo_ai_mvp_v0_2.zip
cd bharatvideo_ai_mvp_v0_2
```

Overlay v0.2 onto the existing v0.1 directory so its `.env` and Docker volumes stay intact:

```bash
./scripts/upgrade_from_v0_1.sh ~/Downloads/bharatvideo_ai_mvp_v0_1
```

Then return to the existing directory:

```bash
cd ~/Downloads/bharatvideo_ai_mvp_v0_1
```

## Real local LLM setup

v0.2 uses Ollama on the Mac host. Check it:

```bash
./scripts/check_ollama.sh
```

If required:

```bash
open -a Ollama
ollama pull llama3.2
```

Important `.env` values:

```env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://host.docker.internal:11434
OLLAMA_MODEL=llama3.2
LLM_FALLBACK_TO_MOCK=true
```

If the real LLM call fails, the project UI shows `planner_fallback_used=true` and the error reason.

## Start Docker services

```bash
docker compose up --build
```

Open:

- Web: http://localhost:3000
- API docs: http://localhost:8000/docs
- API health: http://localhost:8000/health

## Connect the existing Blender engine

Docker cannot directly use the Mac's Homebrew Blender install, so v0.2 includes a guarded host bridge.

Open a second terminal in the BharatVideo project:

```bash
cd ~/Downloads/bharatvideo_ai_mvp_v0_1
./scripts/start_engine_bridge.sh
```

Then in the UI open a generated project and click **Check engine**. Expected status is `ok`.

The bridge accepts only fixed operations; it does not accept arbitrary shell commands. Dynamic project scenes are exported as an explicit episode-plan JSON and passed to the existing renderer with `--render-plan`, so old-plan auto-discovery is not used.

## End-to-end v0.2 flow

```text
Prompt
  ↓
Ollama story planner
  ↓
Hook + running joke + twist
  ↓
Editable Scene[]
  ↓
Edit / AI regenerate one scene
  ↓
Agentic episode-plan export
  ↓
Mac host bridge
  ↓
Existing Blender pipeline
  ↓
3-scene preview MP4
  ↓
Preview in browser
```

## Safety / cost behavior

- No paid video API is enabled in v0.2.
- Ollama is local, so story planning has no external API charge.
- The UI exposes only a 3-scene draft Blender preview button by default.
- The API supports `mode=full`, but use it only after a preview passes.
- The existing `agentic-content-factory` source remains separate; BharatVideo passes it an explicit plan instead of importing/modifying arbitrary internals.

## Tests

From the API directory:

```bash
cd apps/api
python -m pytest -q
```

## Next: v0.3

- Real TTS provider abstraction
- Subtitle generation
- AI image/video provider interfaces (Veo/Runway later, disabled by default)
- Timeline asset model
- per-scene render status and retries
- cost ledger / credit reservation
