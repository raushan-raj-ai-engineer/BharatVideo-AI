# BharatVideo AI Roadmap

## v0.1 — foundation ✅
- Next.js + FastAPI
- PostgreSQL
- Redis/Celery
- mock scene workflow

## v0.2 — real planning + engine bridge ✅
- local Ollama story generation
- Hindi/Hinglish/Kanpuriya planning contract
- scene editor
- single-scene AI rewrite
- SSE job progress
- Agentic Content Factory plan export
- guarded Blender host bridge
- preview artifact in UI

## v0.3 — media pipeline
- TTS abstraction and regional voices
- captions/subtitles
- image-generation provider abstraction
- per-scene media jobs
- retry/fallback policy
- final FFmpeg composition

## v0.4 — commercial controls
- Razorpay
- credit ledger/reservations/refunds
- workspace + brand kit
- usage/cost dashboard
- signed asset URLs

## v0.5 — Canva-like editor foundation
- timeline tracks
- clip trim/reorder
- scene versions
- template library
- export presets
