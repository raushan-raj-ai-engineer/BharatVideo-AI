#!/usr/bin/env bash
set -euo pipefail
SOURCE="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${1:-}"
if [[ -z "$TARGET" ]]; then
  echo "Usage: $0 /path/to/bharatvideo_ai_mvp_v0_1" >&2
  exit 2
fi
TARGET="$(cd "$TARGET" && pwd)"
if [[ "$SOURCE" == "$TARGET" ]]; then
  echo "Run this script from the extracted v0.2 package, not from the target directory." >&2
  exit 4
fi
if [[ ! -f "$TARGET/docker-compose.yml" || ! -d "$TARGET/apps" ]]; then
  echo "Target does not look like BharatVideo v0.1: $TARGET" >&2
  exit 3
fi
BACKUP="$TARGET/.upgrade-backup-v0_1-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
for p in apps engine_adapters scripts docker-compose.yml README.md ARCHITECTURE.md ROADMAP.md .env.example; do
  [[ -e "$TARGET/$p" ]] && cp -R "$TARGET/$p" "$BACKUP/" || true
done
# Preserve user's .env and any local storage. Overlay source code/config only.
for p in apps engine_adapters engine_bridge packages scripts docker-compose.yml README.md ARCHITECTURE.md ROADMAP.md .env.example Makefile .gitignore; do
  rm -rf "$TARGET/$p"
  cp -R "$SOURCE/$p" "$TARGET/$p"
done
ENVFILE="$TARGET/.env"
if [[ -f "$ENVFILE" ]]; then
  add_env(){ local key="$1" value="$2"; grep -q "^${key}=" "$ENVFILE" || printf '\n%s=%s\n' "$key" "$value" >> "$ENVFILE"; }
  add_env LLM_PROVIDER ollama
  add_env OLLAMA_BASE_URL http://host.docker.internal:11434
  add_env OLLAMA_MODEL llama3.2
  add_env LLM_TIMEOUT_SECONDS 120
  add_env LLM_TEMPERATURE 0.7
  add_env LLM_FALLBACK_TO_MOCK true
  if grep -q '^ENGINE_MODE=' "$ENVFILE"; then
    sed -i.bak 's/^ENGINE_MODE=.*/ENGINE_MODE=bridge/' "$ENVFILE" && rm -f "$ENVFILE.bak"
  else
    printf '\nENGINE_MODE=bridge\n' >> "$ENVFILE"
  fi
  add_env ENGINE_BRIDGE_URL http://host.docker.internal:8090
  add_env ENGINE_BRIDGE_TOKEN change-me-local-dev-token
fi
echo "[UPGRADE] v0.2 overlay complete: $TARGET"
echo "[UPGRADE] backup: $BACKUP"
echo "[UPGRADE] existing .env and Docker volumes were preserved"
