# BharatVideo AI v0.2 Architecture

```text
Next.js UI
   │
   ├── Project / Scene editor
   └── SSE job progress
   │
FastAPI
   │
   ├── Project API
   ├── Scene API
   ├── Engine-plan adapter
   └── Engine health
   │
PostgreSQL ── Redis/Celery
                 │
                 ├── Story generation worker
                 │      └── Ollama on macOS host
                 │
                 └── Render worker
                        │
                        └── guarded host bridge :8090
                                │
                                └── agentic-content-factory
                                      └── Blender + FFmpeg
```

## Boundary decisions

### LLM
The API talks to Ollama through HTTP. Story generation returns validated structured JSON. If the provider fails and fallback is enabled, a deterministic scene plan is used and the fallback reason is stored in scene metadata.

### Existing engine
The renderer is not copied into BharatVideo. The host bridge creates a temporary explicit episode plan and calls `content_factory.cartoon.blender_full.cli --render-plan`. This keeps the existing repository isolated and avoids Docker/Homebrew Blender incompatibility.

### Database compatibility
v0.2 adds a new `project_artifacts` table but deliberately does not add new values to the existing PostgreSQL `ProjectStatus` enum, so an upgraded v0.1 database remains usable without an enum migration.

### Scene as unit of work
Scene data remains editable in PostgreSQL. LLM metadata such as dialogue turns, camera, action and props lives in `metadata_json`; this avoids a destructive schema migration while contracts are still evolving.
