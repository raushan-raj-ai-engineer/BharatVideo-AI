from __future__ import annotations

from typing import Any


def _slug_character(value: str) -> str:
    value = value.strip().lower().replace(" ", "_")
    return value or "narrator"


def project_to_agentic_plan(project, scenes) -> dict[str, Any]:
    characters: list[str] = []
    output_scenes: list[dict[str, Any]] = []

    for idx, scene in enumerate(sorted(scenes, key=lambda x: x.order_index), start=1):
        meta = scene.metadata_json or {}
        turns = meta.get("dialogue_turns") or []
        normalized_turns = []
        for turn in turns:
            speaker = _slug_character(str(turn.get("speaker") or "narrator"))
            if speaker != "narrator" and speaker not in characters:
                characters.append(speaker)
            text = str(turn.get("text") or "").strip()
            if text:
                normalized_turns.append({
                    "character_id": speaker,
                    "text": text,
                    "emotion": str(turn.get("emotion") or "neutral").lower(),
                    "pose": str(turn.get("pose") or "idle").lower(),
                    "pause_after_seconds": 0.12,
                })
        if not normalized_turns and scene.dialogue.strip():
            normalized_turns.append({
                "character_id": "narrator",
                "text": scene.dialogue.strip(),
                "emotion": "neutral",
                "pose": "idle",
                "pause_after_seconds": 0.12,
            })

        output_scenes.append({
            "id": idx,
            "location_id": str(meta.get("location_id") or "courtyard"),
            "beat": str(meta.get("beat") or ("cold_open" if idx == 1 else "scene")),
            "camera": str(meta.get("camera") or "speaker_medium"),
            "shot_duration_seconds": float(scene.duration_seconds),
            "setup": str(meta.get("setup") or scene.visual_prompt),
            "dialogue": normalized_turns,
            "visual_action": str(meta.get("visual_action") or "dialogue"),
            "props": list(meta.get("props") or []),
            "camera_action": "dialogue_motivated_3d",
            "transition": "hard_cut",
            "environment_variant": f"bharatvideo_scene_{idx}",
            "blocking_mode": "action",
        })

    if not characters:
        # Existing renderer has known defaults for these recurring cartoon characters.
        characters = ["babuji", "guddu", "bittu"]

    first_meta = (scenes[0].metadata_json or {}) if scenes else {}
    return {
        "title": project.title,
        "topic": project.prompt,
        "language_code": "hindi" if project.language.startswith("hi") else project.language,
        "language_name": project.dialect or project.language,
        "genre": project.style or "family_comedy",
        "characters": characters,
        "story_engine": {
            "source": "bharatvideo_ai_mvp_v0_2",
            "fresh_story": True,
            "dialect": project.dialect,
            "running_joke": first_meta.get("running_joke", ""),
            "twist": first_meta.get("twist", ""),
            "old_plan_autodiscovery": False,
        },
        "scenes": output_scenes,
    }
