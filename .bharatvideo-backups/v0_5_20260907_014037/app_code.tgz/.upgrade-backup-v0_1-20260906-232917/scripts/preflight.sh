#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
echo "[BharatVideo] root=$ROOT"
for cmd in python3 node npm; do
  if command -v "$cmd" >/dev/null 2>&1; then echo "[PASS] $cmd=$(command -v "$cmd")"; else echo "[WARN] $cmd not found"; fi
done
if command -v docker >/dev/null 2>&1; then
  echo "[PASS] docker=$(command -v docker)"
else
  echo "[WARN] Docker not found. Install Docker Desktop for the one-command local stack."
fi
python3 -m compileall -q "$ROOT/apps/api/app" "$ROOT/engine_adapters"
echo "[PASS] Python compile"
python3 - <<PY
import json
from pathlib import Path
root=Path(r'''$ROOT''')
for f in [root/'packages/contracts/project.schema.json', root/'apps/web/package.json', root/'apps/web/tsconfig.json']:
    json.load(open(f))
print('[PASS] JSON contracts')
PY
echo "[PASS] preflight complete"
