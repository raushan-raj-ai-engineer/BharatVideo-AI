# BharatVideo AI — MVP v0.1

Web-first AI video generation scaffold for Indian creators and small businesses.

## What is included
- Next.js + TypeScript UI
- FastAPI modular monolith
- PostgreSQL project/job models
- Redis + Celery worker queue
- Scene-oriented generation contract
- Local object-storage abstraction
- Mock generation engine for safe local development
- Adapter boundary for the existing `agentic-content-factory`
- Docker Compose local stack
- Backend tests

## Current MVP flow
`Prompt -> Project -> Generation Job -> Scene Plan -> Mock Scene Assets -> Final Project Status`

The expensive AI/Blender providers are intentionally behind adapters. This lets the UI/API/job system be built and tested without spending external API credits.

## Run with Docker
```bash
cp .env.example .env
docker compose up --build
```

Open:
- Web: http://localhost:3000
- API docs: http://localhost:8000/docs
- Health: http://localhost:8000/health

## Run API tests locally
```bash
cd apps/api
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
pytest -q
```

## Important architecture rule
A video is never one giant generation request. It is a versioned `Project` containing independently regeneratable `Scene` records and background `GenerationJob` records.

## Existing engine integration
Set:
```env
ENGINE_MODE=agentic
AGENTIC_CONTENT_FACTORY_ROOT=/Users/maa/agentic-content-factory
```
The current adapter is a safe stub. Replace the stub command mapping only after the API/UI/job contracts are stable.

## Phase 2
- Authentication/workspaces
- Razorpay credit ledger
- Real TTS provider abstraction
- Veo/Runway provider abstraction
- Scene regenerate API
- Signed S3/R2 uploads
- WebSocket progress
- Timeline editor

## Mac quick start
```bash
./scripts/bootstrap_mac.sh
docker compose up --build
```

The existing `/Users/maa/agentic-content-factory` repo is mounted read-only into the worker when configured, so this MVP does not modify it.
