from dataclasses import dataclass
from pathlib import Path
import json
import subprocess


@dataclass
class EngineResult:
    output_path: str
    manifest: dict


class AgenticContentFactoryAdapter:
    """Boundary around the existing engine. No internal imports by design."""

    def __init__(self, repo_root: str):
        self.repo_root = Path(repo_root)

    def healthcheck(self) -> None:
        if not self.repo_root.exists():
            raise FileNotFoundError(f"Engine repo not found: {self.repo_root}")
        if not (self.repo_root / "run_cartoon.sh").exists():
            raise FileNotFoundError("Expected run_cartoon.sh not found")

    def generate(self, request: dict) -> EngineResult:
        self.healthcheck()
        # Intentionally disabled in MVP v0.1 so the API cannot accidentally launch
        # an expensive long render. Wire this only after scene/job contracts stabilize.
        raise NotImplementedError("Real engine execution is Phase 2; use MOCK mode in v0.1")
