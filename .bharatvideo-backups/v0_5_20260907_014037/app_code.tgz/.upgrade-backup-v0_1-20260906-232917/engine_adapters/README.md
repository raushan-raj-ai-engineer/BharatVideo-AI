# Engine Adapters

Keep the existing `agentic-content-factory` repository independent initially.

The API should invoke it through an adapter instead of importing arbitrary internal modules. This prevents UI/API work from destabilizing the existing rendering pipeline.

Planned contract:
- input: project/scene JSON
- output: generated asset manifest JSON
- execution: subprocess or dedicated worker
