# 30-Day MVP Roadmap

## Week 1 — Platform foundation
- Project CRUD
- Scene records
- Background jobs
- Storage contract
- Mock generation
- Basic create/projects UI

## Week 2 — Real generation adapters
- LLM script planner
- TTS provider interface
- Image/video provider interface
- Existing Blender engine adapter
- Scene regeneration

## Week 3 — Business model
- Auth/workspaces
- Razorpay
- Credit ledger
- Brand kit
- Usage/cost logging

## Week 4 — Launch readiness
- Progress events
- Export presets
- Captions
- Thumbnail/caption package
- Analytics/admin margin dashboard
- 20 business pilot onboarding
