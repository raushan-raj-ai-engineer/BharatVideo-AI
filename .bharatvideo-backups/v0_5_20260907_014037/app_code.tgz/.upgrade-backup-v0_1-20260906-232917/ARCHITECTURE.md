# Architecture Decisions

## 1. Modular monolith first
FastAPI owns projects, scenes, jobs, billing contracts, and orchestration. Heavy work is delegated to workers.

## 2. Scene-first generation
Every scene can be retried, regenerated, replaced, or routed to a different provider without redoing the entire video.

## 3. Provider abstraction
Generation modes: MOCK, TEMPLATE, AI_IMAGE, AI_VIDEO, BLENDER_3D, USER_MEDIA, HYBRID.

## 4. Cost control
Generation jobs reserve estimated credits before dispatch. Provider calls must later report actual cost per attempt.

## 5. Storage
Database stores metadata/URLs only. Binary media lives in object storage.

## 6. Existing engine
`agentic-content-factory` remains a separate engine and is invoked through `engine_adapters/`. This reduces regression risk in the existing repo.
