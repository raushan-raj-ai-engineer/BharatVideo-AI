from sqlalchemy import select
from app.db.session import SessionLocal
from app.models import GenerationJob, JobStatus, Project, ProjectStatus, Scene
from app.services.scene_planner import plan_mock_scenes
from app.services.storage import LocalStorage
from app.tasks.celery_app import celery


@celery.task(name="generate_project")
def generate_project(job_id: str) -> dict:
    db = SessionLocal()
    storage = LocalStorage()
    try:
        job = db.get(GenerationJob, job_id)
        if not job:
            raise RuntimeError(f"Job not found: {job_id}")
        project = db.get(Project, job.project_id)
        if not project:
            raise RuntimeError(f"Project not found: {job.project_id}")
        job.status = JobStatus.RUNNING
        project.status = ProjectStatus.GENERATING
        job.progress = 5
        db.commit()

        existing = db.scalars(select(Scene).where(Scene.project_id == project.id)).all()
        for scene in existing:
            db.delete(scene)
        db.commit()

        planned = plan_mock_scenes(project.prompt, project.duration_seconds, project.language, project.dialect)
        total = len(planned)
        for idx, p in enumerate(planned, start=1):
            url = storage.write_text_asset(
                f"projects/{project.id}/scenes/scene_{p.order_index+1:02d}.txt",
                f"DIALOGUE\n{p.dialogue}\n\nVISUAL PROMPT\n{p.visual_prompt}\n",
            )
            db.add(Scene(
                project_id=project.id,
                order_index=p.order_index,
                duration_seconds=p.duration_seconds,
                dialogue=p.dialogue,
                visual_prompt=p.visual_prompt,
                generation_mode=p.generation_mode,
                asset_url=url,
            ))
            job.progress = 10 + int((idx / total) * 80)
            db.commit()

        project.status = ProjectStatus.READY
        job.status = JobStatus.SUCCEEDED
        job.progress = 100
        db.commit()
        return {"job_id": job.id, "project_id": project.id, "status": "SUCCEEDED"}
    except Exception as exc:
        if 'job' in locals() and job:
            job.status = JobStatus.FAILED
            job.error = str(exc)
        if 'project' in locals() and project:
            project.status = ProjectStatus.FAILED
        db.commit()
        raise
    finally:
        db.close()
