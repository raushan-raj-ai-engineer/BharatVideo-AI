from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field


class ProjectCreate(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    prompt: str = Field(min_length=5, max_length=4000)
    platform: str = "instagram_reel"
    language: str = "hi-IN"
    dialect: str = "hinglish"
    style: str = "business_funny"
    duration_seconds: int = Field(default=30, ge=5, le=600)
    aspect_ratio: str = "9:16"
    quality: str = "balanced"


class SceneRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    order_index: int
    duration_seconds: float
    dialogue: str
    visual_prompt: str
    generation_mode: str
    asset_url: str | None = None


class ProjectRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    prompt: str
    platform: str
    language: str
    dialect: str
    style: str
    duration_seconds: int
    aspect_ratio: str
    quality: str
    status: str
    estimated_credits: int
    created_at: datetime
    scenes: list[SceneRead] = Field(default_factory=list)


class JobRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    status: str
    progress: int
    error: str | None = None
