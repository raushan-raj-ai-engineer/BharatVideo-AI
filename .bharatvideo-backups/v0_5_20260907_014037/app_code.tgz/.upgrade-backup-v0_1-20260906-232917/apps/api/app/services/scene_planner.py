import math
from dataclasses import dataclass


@dataclass
class PlannedScene:
    order_index: int
    duration_seconds: float
    dialogue: str
    visual_prompt: str
    generation_mode: str


def plan_mock_scenes(prompt: str, duration_seconds: int, language: str, dialect: str) -> list[PlannedScene]:
    scene_count = max(3, min(12, math.ceil(duration_seconds / 6)))
    per_scene = duration_seconds / scene_count
    scenes: list[PlannedScene] = []
    for i in range(scene_count):
        scenes.append(
            PlannedScene(
                order_index=i,
                duration_seconds=round(per_scene, 2),
                dialogue=f"Scene {i+1}: {prompt[:90]}",
                visual_prompt=f"{prompt}. Scene {i+1}. Language={language}, dialect={dialect}.",
                generation_mode="MOCK",
            )
        )
    return scenes
