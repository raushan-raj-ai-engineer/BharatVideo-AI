from pathlib import Path
from app.core.config import get_settings


class LocalStorage:
    def __init__(self) -> None:
        settings = get_settings()
        self.root = Path(settings.local_storage_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.base_url = settings.public_asset_base_url.rstrip("/")

    def write_text_asset(self, key: str, content: str) -> str:
        path = self.root / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return f"{self.base_url}/{key}"
