from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.api.jobs import router as jobs_router
from app.api.projects import router as projects_router
from app.core.config import get_settings
from app.db.session import Base, engine
import app.models  # noqa: F401

settings = get_settings()
Base.metadata.create_all(bind=engine)

app = FastAPI(title="BharatVideo AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(projects_router)
app.include_router(jobs_router)

storage_path = Path(settings.local_storage_dir)
storage_path.mkdir(parents=True, exist_ok=True)
app.mount("/assets", StaticFiles(directory=str(storage_path)), name="assets")


@app.get("/health")
def health():
    return {"status": "ok", "service": "bharatvideo-api", "version": "0.1.0"}
