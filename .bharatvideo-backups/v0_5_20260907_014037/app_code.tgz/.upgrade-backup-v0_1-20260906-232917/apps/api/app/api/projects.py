from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.db.session import get_db
from app.models import GenerationJob, Project, ProjectStatus
from app.schemas.project import JobRead, ProjectCreate, ProjectRead
from app.services.cost_estimator import estimate_credits
from app.tasks.generation import generate_project

router = APIRouter(prefix="/v1/projects", tags=["projects"])


@router.post("", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, db: Session = Depends(get_db)):
    project = Project(**payload.model_dump(), estimated_credits=estimate_credits(payload))
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


@router.get("", response_model=list[ProjectRead])
def list_projects(db: Session = Depends(get_db)):
    stmt = select(Project).options(selectinload(Project.scenes)).order_by(Project.created_at.desc())
    return list(db.scalars(stmt).unique().all())


@router.get("/{project_id}", response_model=ProjectRead)
def get_project(project_id: str, db: Session = Depends(get_db)):
    stmt = select(Project).where(Project.id == project_id).options(selectinload(Project.scenes))
    project = db.scalar(stmt)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


@router.post("/{project_id}/generate", response_model=JobRead, status_code=status.HTTP_202_ACCEPTED)
def queue_generation(project_id: str, db: Session = Depends(get_db)):
    project = db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    job = GenerationJob(project_id=project.id)
    project.status = ProjectStatus.QUEUED
    db.add(job)
    db.commit()
    db.refresh(job)
    async_result = generate_project.delay(job.id)
    job.celery_task_id = async_result.id
    db.commit()
    db.refresh(job)
    return job
