from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./bharatvideo.db"
    redis_url: str = "redis://localhost:6379/0"
    storage_backend: str = "local"
    local_storage_dir: str = "./storage"
    public_asset_base_url: str = "http://localhost:8000/assets"
    cors_origins: str = "http://localhost:3000"
    engine_mode: str = "mock"
    agentic_content_factory_root: str = "../agentic-content-factory"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_origin_list(self) -> list[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
