import os
os.environ["DATABASE_URL"] = "sqlite:///./test_bharatvideo.db"
os.environ["REDIS_URL"] = "redis://localhost:6379/15"
os.environ["LOCAL_STORAGE_DIR"] = "./test_storage"
