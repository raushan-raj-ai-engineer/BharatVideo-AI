from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_create_project():
    response = client.post("/v1/projects", json={
        "title": "Kanpur Gym Reel",
        "prompt": "Create a funny Hinglish gym joining offer reel",
        "platform": "instagram_reel",
        "language": "hi-IN",
        "dialect": "hinglish",
        "duration_seconds": 30,
        "quality": "balanced"
    })
    assert response.status_code == 201
    body = response.json()
    assert body["estimated_credits"] > 0
    assert body["status"] == "DRAFT"
