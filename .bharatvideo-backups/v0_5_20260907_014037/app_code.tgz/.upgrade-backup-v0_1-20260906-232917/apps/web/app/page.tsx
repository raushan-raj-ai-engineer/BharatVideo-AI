import Link from 'next/link';
export default function Home(){return <>
  <section className="hero"><span className="pill">MVP v0.1</span><h1>Regional AI videos for Bharat creators.</h1><p className="muted">Prompt → scenes → voice/visual jobs → export. Start with safe mock generation before connecting paid video APIs.</p></section>
  <div className="grid two"><div className="card"><h2>Create a video</h2><p>Hindi, Hinglish and regional-first project workflow.</p><Link href="/create"><button>New project</button></Link></div><div className="card"><h2>Cost-aware by design</h2><p>Every project estimates credits before expensive generation is dispatched.</p></div></div>
</>}
