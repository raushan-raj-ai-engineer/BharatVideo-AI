import './globals.css';
import Link from 'next/link';

export const metadata = { title: 'BharatVideo AI', description: 'AI video studio for Indian creators' };

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body><main className="shell">
    <nav className="nav"><Link className="brand" href="/">BharatVideo AI</Link><Link href="/create">Create</Link><Link href="/projects">Projects</Link></nav>
    {children}
  </main></body></html>;
}
