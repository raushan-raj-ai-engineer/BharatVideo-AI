'use client';
import {FormEvent,useState} from 'react';
const API=process.env.NEXT_PUBLIC_API_BASE_URL||'http://localhost:8000';
export default function CreatePage(){
 const [msg,setMsg]=useState(''); const [busy,setBusy]=useState(false);
 async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setBusy(true);setMsg(''); const fd=new FormData(e.currentTarget);
 const payload={title:String(fd.get('title')),prompt:String(fd.get('prompt')),platform:String(fd.get('platform')),language:String(fd.get('language')),dialect:String(fd.get('dialect')),duration_seconds:Number(fd.get('duration_seconds')),quality:String(fd.get('quality')),style:'business_funny',aspect_ratio:'9:16'};
 try{const r=await fetch(`${API}/v1/projects`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const p=await r.json(); if(!r.ok)throw new Error(JSON.stringify(p)); const j=await fetch(`${API}/v1/projects/${p.id}/generate`,{method:'POST'}); const job=await j.json(); if(!j.ok)throw new Error(JSON.stringify(job)); setMsg(`Project created. Estimated ${p.estimated_credits} credits. Job: ${job.id}`);}catch(err){setMsg(`Error: ${String(err)}`)}finally{setBusy(false)}}
 return <div className="card"><h1>Create AI Video</h1><form className="grid" onSubmit={submit}>
  <input name="title" required placeholder="Project title" defaultValue="Restaurant Offer Reel"/>
  <textarea name="prompt" required placeholder="Describe the video..." defaultValue="Create a funny Hindi reel for a local restaurant weekend offer"/>
  <div className="row"><select name="platform" defaultValue="instagram_reel"><option value="instagram_reel">Instagram Reel</option><option value="youtube_short">YouTube Short</option><option value="youtube">YouTube</option></select><select name="language" defaultValue="hi-IN"><option value="hi-IN">Hindi</option><option value="en-IN">English India</option></select></div>
  <div className="row"><select name="dialect" defaultValue="hinglish"><option value="hinglish">Hinglish</option><option value="kanpuriya">Kanpuriya</option><option value="standard_hindi">Standard Hindi</option></select><select name="quality" defaultValue="balanced"><option value="economy">Economy</option><option value="balanced">Balanced</option><option value="premium">Premium</option></select></div>
  <input name="duration_seconds" type="number" min="5" max="600" defaultValue="30"/>
  <button disabled={busy}>{busy?'Creating...':'Generate project'}</button>{msg&&<p className={msg.startsWith('Error')?'error':'success'}>{msg}</p>}
 </form></div>
}
