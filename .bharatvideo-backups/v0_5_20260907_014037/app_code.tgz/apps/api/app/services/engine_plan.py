from __future__ import annotations

from typing import Any


BLENDER_ACTORS = ("babuji", "guddu", "bittu")


def _slug_character(value: str) -> str:
    value = value.strip().lower().replace(" ", "_")
    return value or "narrator"


def _speaker_alias(value: str) -> str:
    value = _slug_character(value)
    aliases = {
        "babu": "babuji", "babu_ji": "babuji", "father": "babuji", "dad": "babuji",
        "guddua": "guddu", "guddu_bhaiya": "guddu",
        "bittua": "bittu", "bittu_bhaiya": "bittu",
    }
    return aliases.get(value, value)


def _map_speakers_for_blender(scenes) -> dict[str, str]:
    """Map free-form LLM speaker names onto the renderer's stable actor rig IDs.

    Existing babuji/guddu/bittu names are preserved. Unknown non-narrator names are
    assigned deterministically in first-seen order. This adapter is only for the
    Blender cartoon renderer; the project's original scene metadata remains unchanged.
    """
    mapping: dict[str, str] = {}
    used = set()

    # Preserve known actors first.
    for scene in sorted(scenes, key=lambda x: x.order_index):
        for turn in ((scene.metadata_json or {}).get("dialogue_turns") or []):
            raw = _speaker_alias(str(turn.get("speaker") or "narrator"))
            if raw in BLENDER_ACTORS:
                mapping[raw] = raw
                used.add(raw)

    available = [actor for actor in BLENDER_ACTORS if actor not in used]
    cycle_index = 0
    for scene in sorted(scenes, key=lambda x: x.order_index):
        for turn in ((scene.metadata_json or {}).get("dialogue_turns") or []):
            raw = _speaker_alias(str(turn.get("speaker") or "narrator"))
            if raw == "narrator" or raw in mapping:
                continue
            if available:
                actor = available.pop(0)
            else:
                actor = BLENDER_ACTORS[cycle_index % len(BLENDER_ACTORS)]
                cycle_index += 1
            mapping[raw] = actor
    return mapping




def _estimate_natural_dialogue_seconds(turns: list[dict[str, Any]]) -> float:
    """Conservative speech-budget estimate for Blender preview scenes.

    The V6.4 renderer intentionally refuses unnatural >1.15x speech compression.
    App-authored scene durations can be much shorter than real TTS.  Estimate a
    natural budget from word/character density and turn pauses, then let the
    renderer use its normal QA as the final guard.
    """
    texts = [str(t.get("text") or "").strip() for t in turns if str(t.get("text") or "").strip()]
    if not texts:
        return 2.0
    joined = " ".join(texts)
    words = [w for w in joined.replace("\n", " ").split(" ") if w.strip()]
    visible_chars = sum(1 for ch in joined if not ch.isspace())
    # ~180 wpm baseline plus explicit pause/prosody headroom for expressive Hindi.
    by_words = len(words) * 0.33
    by_chars = visible_chars / 11.0
    speech = max(by_words, by_chars, 1.2)
    pauses = max(0.12, len(texts) * 0.16)
    # Headroom covers punctuation/prosody and the renderer's own safety margin.
    return round(speech + pauses + 0.45, 2)


def _autofit_scene_duration(requested_seconds: float, turns: list[dict[str, Any]]) -> float:
    return round(max(2.0, float(requested_seconds), _estimate_natural_dialogue_seconds(turns)), 2)

def project_to_agentic_plan(project, scenes) -> dict[str, Any]:
    characters: list[str] = []
    output_scenes: list[dict[str, Any]] = []
    speaker_map = _map_speakers_for_blender(scenes)

    for idx, scene in enumerate(sorted(scenes, key=lambda x: x.order_index), start=1):
        meta = scene.metadata_json or {}
        turns = meta.get("dialogue_turns") or []
        normalized_turns = []
        for turn in turns:
            raw_speaker = _speaker_alias(str(turn.get("speaker") or "narrator"))
            speaker = speaker_map.get(raw_speaker, raw_speaker)
            if speaker != "narrator" and speaker not in characters:
                characters.append(speaker)
            text = str(turn.get("text") or "").strip()
            if text:
                normalized_turns.append({
                    "character_id": speaker,
                    "text": text,
                    "emotion": str(turn.get("emotion") or "neutral").lower(),
                    "pose": str(turn.get("pose") or "idle").lower(),
                    "pause_after_seconds": 0.12,
                })
        if not normalized_turns and scene.dialogue.strip():
            # The renderer can play narrator audio, but a visible actor gives a much
            # more useful preview than a silent/motionless cast.
            fallback_actor = BLENDER_ACTORS[(idx - 1) % len(BLENDER_ACTORS)]
            if fallback_actor not in characters:
                characters.append(fallback_actor)
            normalized_turns.append({
                "character_id": fallback_actor,
                "text": scene.dialogue.strip(),
                "emotion": "neutral",
                "pose": "idle",
                "pause_after_seconds": 0.12,
            })

        output_scenes.append({
            "id": idx,
            "location_id": str(meta.get("location_id") or "courtyard"),
            "beat": str(meta.get("beat") or ("cold_open" if idx == 1 else "scene")),
            "camera": str(meta.get("camera") or "speaker_medium"),
            "shot_duration_seconds": _autofit_scene_duration(float(scene.duration_seconds), normalized_turns),
            "setup": str(meta.get("setup") or scene.visual_prompt),
            "dialogue": normalized_turns,
            "visual_action": str(meta.get("visual_action") or "dialogue"),
            "props": list(meta.get("props") or []),
            "camera_action": "dialogue_motivated_3d",
            "transition": "hard_cut",
            "environment_variant": f"bharatvideo_scene_{idx}",
            "blocking_mode": "action",
        })

    if not characters:
        characters = list(BLENDER_ACTORS)

    first_meta = (scenes[0].metadata_json or {}) if scenes else {}
    return {
        "title": project.title,
        "topic": project.prompt,
        "language_code": "hindi" if project.language.startswith("hi") else project.language,
        "language_name": project.dialect or project.language,
        "genre": project.style or "family_comedy",
        "characters": characters[:3],
        "story_engine": {
            "source": "bharatvideo_ai_mvp_v0_3_2",
            "fresh_story": True,
            "dialect": project.dialect,
            "running_joke": first_meta.get("running_joke", ""),
            "twist": first_meta.get("twist", ""),
            "old_plan_autodiscovery": False,
            "blender_actor_map": speaker_map,
            "natural_speech_duration_autofit": True,
        },
        "scenes": output_scenes,
    }
