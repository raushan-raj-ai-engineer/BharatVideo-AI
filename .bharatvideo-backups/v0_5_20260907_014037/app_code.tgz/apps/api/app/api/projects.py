from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.db.session import get_db
from app.models import GenerationJob, Project, ProjectStatus, Scene
from app.schemas.project import EngineRenderRequest, JobRead, ProjectCreate, ProjectRead
from app.services.cost_estimator import estimate_credits
from app.services.engine_plan import project_to_agentic_plan
from app.tasks.generation import generate_project, render_project

router = APIRouter(prefix="/v1/projects", tags=["projects"])


def _project_stmt():
    return select(Project).options(
        selectinload(Project.scenes).selectinload(Scene.media_assets),
        selectinload(Project.artifacts),
        selectinload(Project.media_assets),
    )


@router.post("", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, db: Session = Depends(get_db)):
    project = Project(**payload.model_dump(), estimated_credits=estimate_credits(payload))
    db.add(project)
    db.commit()
    return db.scalar(_project_stmt().where(Project.id == project.id))


@router.get("", response_model=list[ProjectRead])
def list_projects(db: Session = Depends(get_db)):
    stmt = _project_stmt().order_by(Project.created_at.desc())
    return list(db.scalars(stmt).unique().all())


@router.get("/{project_id}", response_model=ProjectRead)
def get_project(project_id: str, db: Session = Depends(get_db)):
    project = db.scalar(_project_stmt().where(Project.id == project_id))
    if not project:
        raise HTTPException(404, "Project not found")
    return project


@router.post("/{project_id}/generate", response_model=JobRead, status_code=status.HTTP_202_ACCEPTED)
def queue_generation(project_id: str, db: Session = Depends(get_db)):
    project = db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    job = GenerationJob(project_id=project.id)
    project.status = ProjectStatus.QUEUED
    db.add(job)
    db.commit()
    db.refresh(job)
    async_result = generate_project.delay(job.id)
    job.celery_task_id = async_result.id
    db.commit()
    db.refresh(job)
    return job


@router.get("/{project_id}/engine-plan")
def export_engine_plan(project_id: str, db: Session = Depends(get_db)):
    project = db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    scenes = list(db.scalars(select(Scene).where(Scene.project_id == project.id).order_by(Scene.order_index)).all())
    if not scenes:
        raise HTTPException(409, "Generate scenes before exporting an engine plan")
    return project_to_agentic_plan(project, scenes)


@router.post("/{project_id}/render", response_model=JobRead, status_code=status.HTTP_202_ACCEPTED)
def queue_render(project_id: str, payload: EngineRenderRequest, db: Session = Depends(get_db)):
    project = db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    # A simple existence check is enough before dispatching the render job.
    if not db.scalar(select(Scene.id).where(Scene.project_id == project.id).limit(1)):
        raise HTTPException(409, "Generate scenes before rendering")
    job = GenerationJob(project_id=project.id)
    project.status = ProjectStatus.QUEUED
    db.add(job)
    db.commit()
    db.refresh(job)
    async_result = render_project.delay(job.id, payload.mode, payload.quality)
    job.celery_task_id = async_result.id
    db.commit()
    db.refresh(job)
    return job
