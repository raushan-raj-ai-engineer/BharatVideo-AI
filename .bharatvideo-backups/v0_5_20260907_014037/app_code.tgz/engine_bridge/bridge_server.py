#!/usr/bin/env python3
"""Minimal guarded host bridge for the existing Agentic Content Factory.

Runs on macOS host so Blender/Homebrew tools remain available. Docker workers call
it through host.docker.internal. No arbitrary shell command is accepted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import threading
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


class BridgeConfig:
    def __init__(self, repo_root: Path, token: str):
        self.repo_root = repo_root.resolve()
        self.token = token
        self.asset_dir = Path(tempfile.gettempdir()) / "bharatvideo_engine_bridge_assets"
        self.asset_dir.mkdir(parents=True, exist_ok=True)
        self.assets: dict[str, tuple[Path, str]] = {}
        self.lock = threading.Lock()

    def python(self) -> str:
        candidates = [
            self.repo_root / ".venv/bin/python",
            self.repo_root / "venv/bin/python",
        ]
        for item in candidates:
            if item.is_file():
                return str(item)
        found = shutil.which("python3")
        if not found:
            raise RuntimeError("No Python interpreter found for Agentic Content Factory")
        return found

    def base_env(self) -> dict[str, str]:
        env = os.environ.copy()
        src = str(self.repo_root / "src")
        env["PYTHONPATH"] = src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        return env


CONFIG: BridgeConfig


def _json(handler: BaseHTTPRequestHandler, status: int, payload: dict):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def _newest_mp4(root: Path) -> Path | None:
    files = [p for p in root.rglob("*.mp4") if p.is_file()]
    return max(files, key=lambda p: p.stat().st_mtime) if files else None


def _estimate_natural_dialogue_seconds(scene: dict) -> float:
    turns = scene.get("dialogue") or []
    texts = [str(t.get("text") or "").strip() for t in turns if str(t.get("text") or "").strip()]
    if not texts:
        return 2.0
    joined = " ".join(texts)
    words = [w for w in joined.replace("\n", " ").split(" ") if w.strip()]
    visible_chars = sum(1 for ch in joined if not ch.isspace())
    speech = max(len(words) * 0.33, visible_chars / 11.0, 1.2)
    pauses = max(0.12, len(texts) * 0.16)
    return round(speech + pauses + 0.45, 2)


def _autofit_plan_dialogue_budgets(plan: dict) -> list[dict]:
    """Mutate render copy only; never changes the user's persisted project."""
    changes = []
    for scene in plan.get("scenes") or []:
        old = max(2.0, float(scene.get("shot_duration_seconds") or 2.0))
        natural = _estimate_natural_dialogue_seconds(scene)
        new = round(max(old, natural), 2)
        if new > old + 0.01:
            scene["shot_duration_seconds"] = new
            changes.append({"scene_id": scene.get("id"), "from": old, "to": new})
    return changes


class Handler(BaseHTTPRequestHandler):
    server_version = "BharatVideoEngineBridge/0.3.2"

    def log_message(self, fmt, *args):
        print(f"[ENGINE BRIDGE] {self.address_string()} - {fmt % args}")

    def authorized(self) -> bool:
        return self.headers.get("X-BharatVideo-Bridge-Token", "") == CONFIG.token

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length <= 0 or length > 2_000_000:
            raise ValueError("Invalid request body size")
        raw = self.rfile.read(length)
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("JSON root must be an object")
        return data

    def do_GET(self):
        if not self.authorized():
            return _json(self, HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
        path = urlparse(self.path).path
        if path == "/health":
            try:
                py = CONFIG.python()
                return _json(self, HTTPStatus.OK, {
                    "status": "ok",
                    "bridge_version": "0.3.2",
                    "repo_root": str(CONFIG.repo_root),
                    "python": py,
                    "repo_exists": CONFIG.repo_root.is_dir(),
                })
            except Exception as exc:
                return _json(self, HTTPStatus.SERVICE_UNAVAILABLE, {"status": "error", "error": str(exc)})
        if path.startswith("/assets/"):
            asset_id = path.rsplit("/", 1)[-1]
            with CONFIG.lock:
                asset = CONFIG.assets.get(asset_id)
            if not asset:
                return _json(self, HTTPStatus.NOT_FOUND, {"error": "asset not found"})
            file_path, content_type = asset
            if not file_path.is_file():
                return _json(self, HTTPStatus.NOT_FOUND, {"error": "asset not found"})
            content = file_path.read_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("X-Content-SHA256", hashlib.sha256(content).hexdigest())
            self.end_headers()
            self.wfile.write(content)
            return
        return _json(self, HTTPStatus.NOT_FOUND, {"error": "not found"})

    def do_POST(self):
        if not self.authorized():
            return _json(self, HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
        path = urlparse(self.path).path
        try:
            if path == "/preflight":
                cmd = [
                    CONFIG.python(), "-m", "content_factory.cartoon.blender_full.cli",
                    "--project", str(CONFIG.repo_root), "--check-only",
                ]
                proc = subprocess.run(
                    cmd, cwd=CONFIG.repo_root, env=CONFIG.base_env(),
                    text=True, capture_output=True, timeout=180,
                )
                return _json(self, HTTPStatus.OK if proc.returncode == 0 else HTTPStatus.BAD_GATEWAY, {
                    "status": "ok" if proc.returncode == 0 else "failed",
                    "returncode": proc.returncode,
                    "stdout": proc.stdout[-8000:],
                    "stderr": proc.stderr[-8000:],
                })

            if path == "/tts":
                data = self.read_json()
                text = str(data.get("text") or "").strip()
                voice = str(data.get("voice") or "Lekha").strip()
                rate = int(data.get("rate") or 185)
                if not text or len(text) > 4000:
                    raise ValueError("text must be 1..4000 characters")
                if not 100 <= rate <= 260:
                    raise ValueError("rate must be 100..260")
                if not all(ch.isalnum() or ch in " _-" for ch in voice):
                    raise ValueError("invalid voice name")
                say = shutil.which("say")
                ffmpeg = shutil.which("ffmpeg")
                if not say or not ffmpeg:
                    raise RuntimeError("macOS say and ffmpeg are required for host TTS")
                asset_id = str(uuid.uuid4())
                aiff = CONFIG.asset_dir / f"{asset_id}.aiff"
                wav = CONFIG.asset_dir / f"{asset_id}.wav"
                proc = subprocess.run([say, "-v", voice, "-r", str(rate), "-o", str(aiff), text], text=True, capture_output=True, timeout=180)
                if proc.returncode != 0:
                    raise RuntimeError(f"say failed: {proc.stderr[-2000:]}")
                proc = subprocess.run([ffmpeg, "-y", "-i", str(aiff), "-ar", "48000", "-ac", "2", str(wav)], text=True, capture_output=True, timeout=180)
                aiff.unlink(missing_ok=True)
                if proc.returncode != 0 or not wav.is_file():
                    raise RuntimeError(f"ffmpeg TTS conversion failed: {proc.stderr[-2000:]}")
                with CONFIG.lock:
                    CONFIG.assets[asset_id] = (wav, "audio/wav")
                return _json(self, HTTPStatus.OK, {
                    "status": "succeeded", "asset_id": asset_id, "voice": voice, "rate": rate,
                    "size_bytes": wav.stat().st_size,
                })

            if path == "/render":
                data = self.read_json()
                plan = data.get("plan")
                if not isinstance(plan, dict) or not isinstance(plan.get("scenes"), list) or not plan["scenes"]:
                    raise ValueError("plan.scenes must be a non-empty list")
                if len(plan["scenes"]) > 40:
                    raise ValueError("Bridge refuses plans above 40 scenes")
                # Renderer V6.4 enforces a strict natural-voice cap (1.15x).
                # Old/saved app plans may carry 2-3s scene slots for 5s of TTS.
                # Expand only the transient render plan; persisted project timing stays untouched.
                duration_changes = _autofit_plan_dialogue_budgets(plan)
                if duration_changes:
                    print(f"[ENGINE BRIDGE] natural speech auto-fit: {duration_changes}")

                quality = str(data.get("quality") or "draft")
                if quality not in {"draft", "standard", "high"}:
                    raise ValueError("invalid quality")
                max_scenes = data.get("max_scenes")
                if max_scenes is not None:
                    max_scenes = int(max_scenes)
                    if not 1 <= max_scenes <= 12:
                        raise ValueError("max_scenes must be 1..12 or null")

                render_id = str(uuid.uuid4())
                work_dir = Path(tempfile.gettempdir()) / f"bharatvideo_render_{render_id}"
                output_dir = work_dir / "output"
                output_dir.mkdir(parents=True, exist_ok=True)
                plan_path = work_dir / "episode_plan.json"
                plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

                # Validate with the *actual installed renderer contract* before spending
                # time launching Blender. This catches plan/schema problems separately.
                validate_code = (
                    "from content_factory.cartoon.blender_full.plan_adapter import load_episode_plan; "
                    f"p=load_episode_plan({str(plan_path)!r}); "
                    "print(f'PLAN_OK scenes={len(p.scenes)} characters={p.characters}')"
                )
                validate_proc = subprocess.run(
                    [CONFIG.python(), "-c", validate_code],
                    cwd=CONFIG.repo_root, env=CONFIG.base_env(),
                    text=True, capture_output=True, timeout=60,
                )
                if validate_proc.returncode != 0:
                    print("[ENGINE BRIDGE] plan validation FAILED")
                    print(validate_proc.stdout[-4000:])
                    print(validate_proc.stderr[-8000:])
                    return _json(self, HTTPStatus.UNPROCESSABLE_ENTITY, {
                        "status": "failed", "stage": "plan_validation",
                        "returncode": validate_proc.returncode,
                        "stdout": validate_proc.stdout[-8000:],
                        "stderr": validate_proc.stderr[-12000:],
                    })

                cmd = [
                    CONFIG.python(), "-m", "content_factory.cartoon.blender_full.cli",
                    "--project", str(CONFIG.repo_root),
                    "--render-plan", str(plan_path),
                    "--output-dir", str(output_dir),
                    "--quality", quality,
                    "--fresh",
                ]
                if max_scenes is not None:
                    cmd += ["--max-scenes", str(max_scenes)]
                print(
                    f"[ENGINE BRIDGE] render start id={render_id} quality={quality} "
                    f"max_scenes={max_scenes or 'ALL'} plan={plan_path}"
                )
                proc = subprocess.run(
                    cmd, cwd=CONFIG.repo_root, env=CONFIG.base_env(),
                    text=True, capture_output=True,
                )
                if proc.returncode != 0:
                    print(
                        f"[ENGINE BRIDGE] render FAILED id={render_id} "
                        f"returncode={proc.returncode}"
                    )
                    if proc.stdout:
                        print("[ENGINE BRIDGE] renderer stdout tail:\n" + proc.stdout[-6000:])
                    if proc.stderr:
                        print("[ENGINE BRIDGE] renderer stderr tail:\n" + proc.stderr[-12000:])
                    return _json(self, HTTPStatus.BAD_GATEWAY, {
                        "status": "failed", "stage": "renderer",
                        "returncode": proc.returncode,
                        "stdout": proc.stdout[-12000:], "stderr": proc.stderr[-16000:],
                    })
                mp4 = _newest_mp4(output_dir)
                if not mp4:
                    return _json(self, HTTPStatus.BAD_GATEWAY, {
                        "status": "failed", "error": "Renderer completed but no MP4 was found",
                        "stdout": proc.stdout[-12000:], "stderr": proc.stderr[-12000:],
                    })
                stable = CONFIG.asset_dir / f"{render_id}.mp4"
                shutil.copy2(mp4, stable)
                with CONFIG.lock:
                    CONFIG.assets[render_id] = (stable, "video/mp4")
                return _json(self, HTTPStatus.OK, {
                    "status": "succeeded",
                    "duration_autofit": duration_changes,
                    "asset_id": render_id,
                    "output_file": str(mp4),
                    "size_bytes": stable.stat().st_size,
                    "stdout_tail": proc.stdout[-4000:],
                })
        except (ValueError, json.JSONDecodeError) as exc:
            return _json(self, HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except Exception as exc:
            return _json(self, HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
        return _json(self, HTTPStatus.NOT_FOUND, {"error": "not found"})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=os.getenv("HOST_AGENTIC_CONTENT_FACTORY_ROOT", "/Users/maa/agentic-content-factory"))
    parser.add_argument("--token", default=os.getenv("ENGINE_BRIDGE_TOKEN", "change-me-local-dev-token"))
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8090)
    args = parser.parse_args()

    global CONFIG
    CONFIG = BridgeConfig(Path(args.repo).expanduser(), args.token)
    if not CONFIG.repo_root.is_dir():
        raise SystemExit(f"Repo not found: {CONFIG.repo_root}")
    print(f"[ENGINE BRIDGE] repo={CONFIG.repo_root}")
    print(f"[ENGINE BRIDGE] listening=http://{args.host}:{args.port}")
    print("[ENGINE BRIDGE] only /health, /preflight, validated /render and guarded /tts are allowed")
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
