# V0.7 pricing + auth

Plans are credit packs for the MVP, not silently auto-renewing subscriptions:

- Free — ₹0 — 30 signup credits
- Creator — ₹299 — 250 credits
- Pro — ₹799 — 800 credits
- Business — ₹1,499 — 1,800 credits

Default billing is Mock/Test mode. Razorpay integration is server-side order creation plus Standard Checkout and HMAC signature verification. Switch to Live keys only after the Test flow and account/KYC requirements are complete.

Current local credit costs:

- Story + scene planning: 2 credits
- Single-scene regeneration: 1 credit
- 3-scene 3D preview: 8 credits
- Full draft render: 35 credits
- Higher full render: 60 credits

These are product-policy values and can be tuned later using actual GPU/API cost data.
