# V0.7 one-shot upgrade

```bash
cd ~/Downloads
unzip -o bharatvideo_ai_mvp_v0_7.zip
cd bharatvideo_ai_mvp_v0_7
./install_and_start_v0_7.sh ~/Downloads/bharatvideo_ai_mvp_v0_1 /Users/maa/agentic-content-factory
```

The installer preserves `.env`, `.git`, PostgreSQL/local-storage Docker volumes and render artifacts. It backs up application code and the active V6.6 timing files, checks the active import paths and timing regression, rebuilds Docker, restarts bridge 0.7.0 and verifies the new auth/billing/video-plan markers.

After startup open `http://localhost:3000`, register the first account, then open the existing project. The first account automatically claims pre-auth legacy projects.
