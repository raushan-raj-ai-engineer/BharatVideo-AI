from __future__ import annotations

from typing import Any


BLENDER_ACTORS = ("babuji", "guddu", "bittu")


def _slug_character(value: str) -> str:
    value = value.strip().lower().replace(" ", "_")
    return value or "narrator"


def _speaker_alias(value: str) -> str:
    value = _slug_character(value)
    aliases = {
        "babu": "babuji", "babu_ji": "babuji", "father": "babuji", "dad": "babuji",
        "guddua": "guddu", "guddu_bhaiya": "guddu",
        "bittua": "bittu", "bittu_bhaiya": "bittu",
    }
    return aliases.get(value, value)


def _map_speakers_for_blender(scenes) -> dict[str, str]:
    """Map free-form LLM speaker names onto the renderer's stable actor rig IDs.

    Existing babuji/guddu/bittu names are preserved. Unknown non-narrator names are
    assigned deterministically in first-seen order. This adapter is only for the
    Blender cartoon renderer; the project's original scene metadata remains unchanged.
    """
    mapping: dict[str, str] = {}
    used = set()

    # Preserve known actors first.
    for scene in sorted(scenes, key=lambda x: x.order_index):
        for turn in ((scene.metadata_json or {}).get("dialogue_turns") or []):
            raw = _speaker_alias(str(turn.get("speaker") or "narrator"))
            if raw in BLENDER_ACTORS:
                mapping[raw] = raw
                used.add(raw)

    available = [actor for actor in BLENDER_ACTORS if actor not in used]
    cycle_index = 0
    for scene in sorted(scenes, key=lambda x: x.order_index):
        for turn in ((scene.metadata_json or {}).get("dialogue_turns") or []):
            raw = _speaker_alias(str(turn.get("speaker") or "narrator"))
            if raw == "narrator" or raw in mapping:
                continue
            if available:
                actor = available.pop(0)
            else:
                actor = BLENDER_ACTORS[cycle_index % len(BLENDER_ACTORS)]
                cycle_index += 1
            mapping[raw] = actor
    return mapping




def _estimate_natural_dialogue_seconds(turns: list[dict[str, Any]]) -> float:
    """Conservative pre-render timing estimate for expressive Hindi/Kanpuri TTS.

    This is deliberately generous. The renderer V6.6 still measures the actual
    generated waveforms and can extend again, so this is an early UX/cost signal,
    not the final source of truth.
    """
    texts = [str(t.get("text") or "").strip() for t in turns if str(t.get("text") or "").strip()]
    if not texts:
        return 2.0
    joined = " ".join(texts)
    words = [w for w in joined.replace("\n", " ").split(" ") if w.strip()]
    visible_chars = sum(1 for ch in joined if not ch.isspace())
    # Expressive Hindi/Kanpuri speech often lands around 1.7-2.1 words/sec once
    # punctuation and comic timing are included. Use the slower edge + char guard.
    by_words = len(words) * 0.58
    by_chars = visible_chars / 8.0
    speech = max(by_words, by_chars, 2.5)
    pauses = max(0.18, len(texts) * 0.20)
    return round(max(4.0, speech + pauses + 0.75), 2)


def _autofit_scene_duration(requested_seconds: float, turns: list[dict[str, Any]]) -> float:
    return round(max(2.0, float(requested_seconds), _estimate_natural_dialogue_seconds(turns)), 2)


def timing_report_for_scenes(scenes) -> list[dict[str, Any]]:
    report: list[dict[str, Any]] = []
    for scene in sorted(scenes, key=lambda x: x.order_index):
        meta = scene.metadata_json or {}
        turns = meta.get("dialogue_turns") or []
        requested = round(float(scene.duration_seconds), 2)
        recommended = _autofit_scene_duration(requested, turns)
        delta = round(recommended - requested, 2)
        report.append({
            "scene_id": scene.id,
            "scene_number": int(scene.order_index) + 1,
            "requested_seconds": requested,
            "recommended_seconds": recommended,
            "delta_seconds": delta,
            "status": "RISK" if delta > 0.01 else "OK",
            "dialogue_turns": len(turns),
        })
    return report


def project_to_agentic_plan(project, scenes) -> dict[str, Any]:
    characters: list[str] = []
    output_scenes: list[dict[str, Any]] = []
    speaker_map = _map_speakers_for_blender(scenes)

    for idx, scene in enumerate(sorted(scenes, key=lambda x: x.order_index), start=1):
        meta = scene.metadata_json or {}
        turns = meta.get("dialogue_turns") or []
        normalized_turns = []
        for turn in turns:
            raw_speaker = _speaker_alias(str(turn.get("speaker") or "narrator"))
            speaker = speaker_map.get(raw_speaker, raw_speaker)
            if speaker != "narrator" and speaker not in characters:
                characters.append(speaker)
            text = str(turn.get("text") or "").strip()
            if text:
                normalized_turns.append({
                    "character_id": speaker,
                    "text": text,
                    "emotion": str(turn.get("emotion") or "neutral").lower(),
                    "pose": str(turn.get("pose") or "idle").lower(),
                    "pause_after_seconds": 0.12,
                })
        if not normalized_turns and scene.dialogue.strip():
            # The renderer can play narrator audio, but a visible actor gives a much
            # more useful preview than a silent/motionless cast.
            fallback_actor = BLENDER_ACTORS[(idx - 1) % len(BLENDER_ACTORS)]
            if fallback_actor not in characters:
                characters.append(fallback_actor)
            normalized_turns.append({
                "character_id": fallback_actor,
                "text": scene.dialogue.strip(),
                "emotion": "neutral",
                "pose": "idle",
                "pause_after_seconds": 0.12,
            })

        comedy = "kanpuri" in str(project.style).lower() or "comedy" in str(project.style).lower()
        context = f"{project.prompt} {scene.visual_prompt} {meta.get('setup','')}".lower()
        props = list(meta.get("props") or [])
        if not props and ("ai" in context or "phone" in context or "mobile" in context):
            props = ["ai_phone"]
        elif not props and comedy:
            props = ["chai_glass" if idx % 2 else "charpai"]
        action_cycle = ["mock_shock", "snatch_phone", "whisper", "phone_pass", "ai_interview", "backpedal", "offer_sweets"]
        visual_action = str(meta.get("visual_action") or "dialogue")
        if comedy and visual_action in {"dialogue", "talk", "idle"}:
            visual_action = action_cycle[(idx - 1) % len(action_cycle)]
        camera_cycle = ["speaker_close_up", "speaker_close_up", "speaker_medium", "speaker_medium", "speaker_close_up", "speaker_medium"]
        camera = str(meta.get("camera") or "speaker_medium")
        if comedy and (idx == 1 or camera == "speaker_medium"):
            camera = camera_cycle[(idx - 1) % len(camera_cycle)]
        blocking = list(meta.get("blocking") or [])
        if comedy and not blocking:
            blocking = [
                {"character":"babuji","action":visual_action,"strength":1.0},
                {"character":"guddu","action":"approach_or_recoil","strength":0.8},
                {"character":"bittu","action":"listener_reaction_or_whisper","strength":0.9},
            ]
        expressions = list(meta.get("expression_beats") or [])
        if comedy and not expressions:
            expressions = [
                {"character":"babuji","emotion":"shock" if idx == 1 else "confused","at":0.22},
                {"character":"guddu","emotion":"worried","at":0.48},
                {"character":"bittu","emotion":"smug","at":0.68},
            ]
        output_scenes.append({
            "id": idx,
            "location_id": str(meta.get("location_id") or "courtyard"),
            "beat": str(meta.get("beat") or ("cold_open" if idx == 1 else "scene")),
            "camera": camera,
            "shot_duration_seconds": _autofit_scene_duration(float(scene.duration_seconds), normalized_turns),
            "setup": str(meta.get("setup") or scene.visual_prompt),
            "dialogue": normalized_turns,
            "visual_action": visual_action,
            "props": props,
            "visual_characters": list(meta.get("visual_characters") or (list(BLENDER_ACTORS) if comedy else [])),
            "blocking": blocking,
            "expression_beats": expressions,
            "lip_sync_mode": str(meta.get("lip_sync_mode") or ("viseme_ready_v07" if comedy else "speech_reactive")),
            "story_prop_required": bool(meta.get("story_prop_required", comedy)),
            "hero_insert": "ai_phone_close_up" if comedy and idx == 1 and "ai_phone" in props else None,
            "hero_insert_seconds": 1.75 if comedy and idx == 1 and "ai_phone" in props else 0.0,
            "performance_lock_v63": bool(comedy and idx <= 3),
            "camera_action": "dialogue_motivated_3d",
            "transition": "hard_cut",
            "environment_variant": f"bharatvideo_scene_{idx}",
            "blocking_mode": "action",
        })

    if "kanpuri" in str(project.style).lower() or "comedy" in str(project.style).lower():
        characters = list(BLENDER_ACTORS)
    elif not characters:
        characters = list(BLENDER_ACTORS)

    first_meta = (scenes[0].metadata_json or {}) if scenes else {}
    return {
        "title": project.title,
        "topic": project.prompt,
        "language_code": "hindi" if project.language.startswith("hi") else project.language,
        "language_name": project.dialect or project.language,
        "genre": project.style or "family_comedy",
        "characters": characters[:3],
        "story_engine": {
            "source": "bharatvideo_ai_mvp_v0_7",
            "fresh_story": True,
            "dialect": project.dialect,
            "running_joke": first_meta.get("running_joke", ""),
            "twist": first_meta.get("twist", ""),
            "old_plan_autodiscovery": False,
            "blender_actor_map": speaker_map,
            "natural_speech_duration_autofit": True,
            "performance_lock_v07": True,
            "three_character_comedy_lock": True,
            "story_prop_blocking": True,
        },
        "scenes": output_scenes,
    }
