from __future__ import annotations

import hashlib
import hmac
from datetime import datetime, timedelta
import httpx
from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models import PaymentOrder, Subscription, User
from app.services.security import add_credits

PLANS = {
    "free": {"id": "free", "name": "Free", "price_inr": 0, "credits": 30, "tagline": "Try the studio", "features": ["30 signup credits", "Draft + 3D preview", "720p preview", "Watermark-ready"]},
    "creator": {"id": "creator", "name": "Creator", "price_inr": 299, "credits": 250, "tagline": "For regular creators", "features": ["250 credits", "1080p exports", "Neural Hindi voice", "Scene regenerate", "No app watermark"]},
    "pro": {"id": "pro", "name": "Pro", "price_inr": 799, "credits": 800, "tagline": "Best value", "popular": True, "features": ["800 credits", "Long-form 3D video", "Regional language profiles", "Priority renders", "Premium provider-ready"]},
    "business": {"id": "business", "name": "Business", "price_inr": 1499, "credits": 1800, "tagline": "For brands & agencies", "features": ["1,800 credits", "Commercial projects", "Brand-ready workflow", "Multiple campaigns", "Priority support"]},
}


def public_plans() -> list[dict]:
    return list(PLANS.values())


def plan(plan_id: str) -> dict:
    item = PLANS.get(plan_id)
    if not item or plan_id == "free":
        raise HTTPException(400, "Paid plan not found")
    return item


def create_checkout(db: Session, user: User, plan_id: str) -> dict:
    settings = get_settings()
    item = plan(plan_id)
    amount_paise = int(item["price_inr"] * 100)
    order = PaymentOrder(user_id=user.id, plan_id=plan_id, amount_paise=amount_paise, credits=item["credits"], provider=settings.billing_mode)
    db.add(order); db.flush()
    if settings.billing_mode == "razorpay":
        if not settings.razorpay_key_id or not settings.razorpay_key_secret:
            raise HTTPException(503, "Razorpay is selected but API keys are missing")
        try:
            with httpx.Client(timeout=20.0) as client:
                response = client.post(
                    "https://api.razorpay.com/v1/orders",
                    auth=(settings.razorpay_key_id, settings.razorpay_key_secret),
                    json={"amount": amount_paise, "currency": "INR", "receipt": f"bv_{order.id[:18]}", "notes": {"user_id": user.id, "plan_id": plan_id}},
                )
                response.raise_for_status()
                data = response.json()
        except Exception as exc:
            raise HTTPException(502, f"Razorpay order creation failed: {exc}") from exc
        order.provider_order_id = data["id"]
        db.commit()
        return {"mode": "razorpay", "order_id": order.id, "provider_order_id": order.provider_order_id, "key_id": settings.razorpay_key_id, "amount": amount_paise, "currency": "INR", "plan": item}
    order.provider_order_id = f"mock_{order.id}"
    db.commit()
    return {"mode": "mock", "order_id": order.id, "provider_order_id": order.provider_order_id, "amount": amount_paise, "currency": "INR", "plan": item}


def _activate(db: Session, user: User, order: PaymentOrder, provider_payment_id: str | None = None) -> dict:
    if order.status == "paid":
        return {"status": "already_paid", "plan_id": user.plan_id}
    item = plan(order.plan_id)
    order.status = "paid"; order.provider_payment_id = provider_payment_id; order.completed_at = datetime.utcnow()
    user.plan_id = order.plan_id
    db.add(Subscription(user_id=user.id, plan_id=order.plan_id, status="active", provider=order.provider, provider_reference=provider_payment_id or order.provider_order_id, expires_at=datetime.utcnow()+timedelta(days=30)))
    add_credits(db, user.id, int(item["credits"]), "PURCHASE", f"{item['name']} plan credits", order.id)
    db.commit()
    return {"status": "paid", "plan_id": user.plan_id, "credits_added": item["credits"]}


def complete_mock(db: Session, user: User, order_id: str) -> dict:
    settings = get_settings()
    if settings.billing_mode != "mock":
        raise HTTPException(400, "Mock checkout is disabled")
    order = db.get(PaymentOrder, order_id)
    if not order or order.user_id != user.id:
        raise HTTPException(404, "Order not found")
    return _activate(db, user, order, f"mockpay_{order.id}")


def verify_razorpay(db: Session, user: User, *, order_id: str, razorpay_order_id: str, payment_id: str, signature: str) -> dict:
    settings = get_settings()
    order = db.get(PaymentOrder, order_id)
    if not order or order.user_id != user.id:
        raise HTTPException(404, "Order not found")
    if order.provider_order_id != razorpay_order_id:
        raise HTTPException(400, "Order mismatch")
    expected = hmac.new(settings.razorpay_key_secret.encode(), f"{razorpay_order_id}|{payment_id}".encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise HTTPException(400, "Payment signature verification failed")
    return _activate(db, user, order, payment_id)
