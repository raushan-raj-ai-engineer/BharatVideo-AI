from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import get_db
from app.models import CreditLedger, PaymentOrder, User
from app.schemas.auth import CheckoutRequest, MockCompleteRequest, VerifyPaymentRequest
from app.services.billing import complete_mock, create_checkout, public_plans, verify_razorpay
from app.services.security import credit_balance, get_current_user

router = APIRouter(prefix="/v1/billing", tags=["billing"])


@router.get("/plans")
def plans():
    settings = get_settings()
    return {"billing_mode": settings.billing_mode, "plans": public_plans()}


@router.get("/account")
def account(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ledger = list(db.scalars(select(CreditLedger).where(CreditLedger.user_id == user.id).order_by(CreditLedger.created_at.desc()).limit(30)).all())
    orders = list(db.scalars(select(PaymentOrder).where(PaymentOrder.user_id == user.id).order_by(PaymentOrder.created_at.desc()).limit(10)).all())
    return {
        "user": {"id": user.id, "name": user.name, "email": user.email, "plan_id": user.plan_id},
        "credits": credit_balance(db, user.id),
        "ledger": [{"id": x.id, "amount": x.amount, "kind": x.kind, "description": x.description, "created_at": x.created_at.isoformat()} for x in ledger],
        "orders": [{"id": x.id, "plan_id": x.plan_id, "status": x.status, "amount_paise": x.amount_paise, "provider": x.provider} for x in orders],
    }


@router.post("/checkout")
def checkout(payload: CheckoutRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return create_checkout(db, user, payload.plan_id)


@router.post("/mock-complete")
def mock_complete(payload: MockCompleteRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return complete_mock(db, user, payload.order_id)


@router.post("/verify")
def verify(payload: VerifyPaymentRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return verify_razorpay(db, user, order_id=payload.order_id, razorpay_order_id=payload.razorpay_order_id, payment_id=payload.razorpay_payment_id, signature=payload.razorpay_signature)
