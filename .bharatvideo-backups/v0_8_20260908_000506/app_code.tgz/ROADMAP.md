# After V0.7

V0.7 is the first product-shaped local release: accounts, credits, pricing and stronger deterministic 3D planning.

Next quality priorities:

1. Worker-level true phoneme/viseme mouth shapes (V0.7 only emits viseme-ready metadata while preserving current speech-reactive animation).
2. More visible locomotion distance and prop contact constraints inside `worker_full.py`.
3. Character model/hand/clothing quality upgrade.
4. Brand kit and uploaded business/product assets.
5. External AI-video provider adapters for premium cinematic shots.
6. Razorpay webhook hardening and recurring subscription product once the one-off Test/Live payment flow is proven.
