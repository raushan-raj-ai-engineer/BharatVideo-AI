# BharatVideo AI V0.7 — Accounts, Pricing + Better 3D Video

V0.7 is one consolidated upgrade over V0.6. It keeps the V6.6 natural-voice timing safety and neural Hindi TTS, and adds two product layers: real account/pricing infrastructure and a stronger 3D performance plan for the recurring comedy cast.

## Product features

- Register / login with PBKDF2-SHA256 password hashing and signed expiring bearer sessions.
- Protected projects, scenes, jobs, media and analytics by account ownership.
- First registered account safely claims legacy projects created before auth existed.
- Free signup credits and a persistent credit ledger.
- India-focused plans: Free, Creator ₹299, Pro ₹799, Business ₹1,499.
- Safe `BILLING_MODE=mock` by default. Optional Razorpay order + Checkout + signature verification path.
- Account page with current plan, balance and credit history.

## Video improvements in the same patch

- Kanpuri/comedy projects force the primary generation mode to `BLENDER_3D` instead of falling back to black/white TEMPLATE cards.
- `babuji`, `guddu`, `bittu` are locked as the recurring 3D cast for comedy scenes.
- Legacy scenes are upgraded at render-plan time, so existing projects do not need to be recreated.
- Story props are inferred when missing (`ai_phone` for AI/phone stories; simple courtyard props otherwise).
- Static dialogue beats are upgraded to physical-action directives such as prop reveal/recoil, approach/point, whisper lean, prop handoff, sit interview, backpedal reaction and chase step.
- Reaction camera and expression-beat metadata is included in every comedy render plan.
- `viseme_ready_v07` metadata is emitted for future/worker-level phoneme refinement while existing speech-reactive mouth animation remains compatible.

## One-shot install + start

```bash
cd ~/Downloads
unzip -o bharatvideo_ai_mvp_v0_7.zip
cd bharatvideo_ai_mvp_v0_7

./install_and_start_v0_7.sh \
  ~/Downloads/bharatvideo_ai_mvp_v0_1 \
  /Users/maa/agentic-content-factory
```

Then open `http://localhost:3000`.

### First run

1. Register your first account. It receives 30 credits and claims existing legacy projects.
2. Open Pricing. In the default Mock/Test Billing mode, plan checkout adds test credits and charges no real money.
3. Open an existing comedy project and render the Real 3D Preview. V0.7 applies cast/prop/action upgrades even to old scene records.

## Razorpay

Default `.env` uses `BILLING_MODE=mock`. To test Razorpay instead:

```env
BILLING_MODE=razorpay
RAZORPAY_KEY_ID=rzp_test_...
RAZORPAY_KEY_SECRET=...
AUTH_SECRET=replace-with-a-long-random-secret
```

Use Razorpay Test keys before Live mode. Do not expose the key secret to the browser.

## Safety / compatibility

- Existing `.env`, PostgreSQL Docker volume, local storage, `.git` and rendered assets are preserved.
- New auth/billing data uses new tables; no destructive change to existing project/scene/media tables.
- V6.6 engine timing fix and neural TTS hook remain installed and verified.
- Static storyboard remains available only as an explicitly labelled debug path.

## Validation

See `VALIDATION_V0_7.md`.
