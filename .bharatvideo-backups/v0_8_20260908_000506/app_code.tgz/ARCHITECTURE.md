# BharatVideo AI V0.7 Architecture

## Account boundary

Browser -> signed bearer token -> FastAPI auth dependency -> User -> ProjectOwner -> Project/Scene/Job/Media.

Authentication tables are additive; existing project schema is untouched. The first account claims legacy unowned projects once.

## Billing boundary

Pricing page -> `/v1/billing/checkout` -> Mock/Test provider or Razorpay Orders API -> verification -> Subscription record + positive CreditLedger entry.

Generation and 3D render endpoints write negative CreditLedger entries before work is queued. Insufficient balance returns HTTP 402.

## Video-performance boundary

Prompt/legacy scene -> V0.7 performance adapter -> V6.6 renderer.

For comedy the adapter forces:

- global and scene-visible cast: babuji/guddu/bittu;
- Blender 3D generation mode;
- story prop inference;
- known V6.x action names (`mock_shock`, `snatch_phone`, `whisper`, `phone_pass`, `ai_interview`, `backpedal`);
- reaction/close camera intent;
- opening `ai_phone_close_up` directive when an AI-phone prop exists;
- expression and blocking metadata;
- existing V6.6 natural speech duration reconciliation.

Static storyboard remains an explicit debug path and is not the production default.
